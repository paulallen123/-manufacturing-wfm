# Autonomy safety model

Language models may classify, explain and propose. They are never the execution authority. All autonomous execution passes through the deterministic safety kernel, which enforces tenant equality, an explicit action allowlist, reversibility, successful dry-run validation, independent evidence and a high confidence threshold.

Autonomous payroll release/pay-rule mutation, identity and privilege changes, security/secret policy changes, cross-tenant actions, destructive data operations, audit deletion and forced production promotion are prohibited. Unknown actions fail closed.
