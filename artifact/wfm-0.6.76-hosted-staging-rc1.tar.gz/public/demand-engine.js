/* v0.6 Demand planning and confidential department benchmarks.
 * Pure, deterministic functions shared by browser and authenticated server.
 * Forecasts are proposals: never modify employee pay, attendance or assignments.
 */
(function(root){
'use strict';
const E=root.WFMEngine||(typeof require==='function'?require('./engine'):null);
const C=root.WFMCost||(typeof require==='function'?require('./cost-engine'):null);
const R=root.WFMWorkRules||(typeof require==='function'?require('./work-rules'):null);
const NOW='2026-09-14', DAY=86400000;
const assert=E.assert, copy=x=>structuredClone(x), round=(x,n=2)=>Math.round((x+Number.EPSILON)*10**n)/10**n;
const sum=(xs,key)=>xs.reduce((a,x)=>a+(key?x[key]:x),0);
const ratio=(n,d)=>d>0?round(100*n/d):null;
const add=C.addDays, week=C.weekOf, dow=d=>new Date(d+'T12:00Z').getUTCDay();
function currentLocalDate(){return new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/London',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());}
const SOURCES=[
{id:'ons-2025',title:'ONS sickness absence, UK labour market 2025',url:'https://www.ons.gov.uk/employmentandlabourmarket/peopleinwork/labourproductivity/articles/sicknessabsenceinthelabourmarket/2025',published:'2026-05-01',checked:'2026-09-14'},
{id:'makeuk-2026',title:'Make UK Absence Benchmark 2026',url:'https://www.makeuk.org/insights/reports/absence-benchmark-2026',published:'2026-04-20',checked:'2026-09-14'},
{id:'ico',title:'ICO: handling sickness and injury records',url:'https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/employment/information-about-workers-health/how-do-we-handle-sickness-and-injury-records/',checked:'2026-09-14'},
{id:'acas',title:'Acas: lay-offs and short-time working',url:'https://www.acas.org.uk/lay-offs-and-short-time-working',checked:'2026-09-14'},
{id:'netsuite',title:'Oracle NetSuite sales-order REST record',url:'https://docs.oracle.com/en/cloud/saas/netsuite/ns-online-help/section_159665260887.html',checked:'2026-09-14'},
{id:'businesscentral',title:'Microsoft Business Central sales order lines',url:'https://learn.microsoft.com/en-us/dynamics365/business-central/dev-itpro/api-reference/v2.0/api/dynamics_salesorderline_get',checked:'2026-09-14'}
];
function access(s,a,scope=a.personId){assert(a&&['manager','director','supervisor'].includes(a.role),'Operational manager access required.',403);E.requireManager(s,a);assert(E.descendants(s.org,a.personId).has(scope),'Department is outside your reporting scope.',403);return E.allowedPeople(s,a,scope);}
function departments(s,a,scope=a.personId){const ids=new Set(access(s,a,scope).map(p=>p.manager));return s.org.filter(n=>ids.has(n.id));}
function canConfigure(a){return (a.permissions||[]).includes('company.configure');}
function decorate(s){
 if(s.demandPlanning){s.demandPlanning.costBenchmarks??={};return s;}
 const products=[
 {id:'CNC-A',department:'s1',name:'Precision component',unit:'pieces',minutesPerUnit:12,batchUnits:100,setupHours:0.5,productiveFraction:.85,hoursPer1000Sales:5.4,skill:'CNC'},
 {id:'ASM-B',department:'s2',name:'Assembly kit',unit:'kits',minutesPerUnit:18,batchUnits:80,setupHours:.4,productiveFraction:.86,hoursPer1000Sales:4.2,skill:'Assembly'},
 {id:'PACK-C',department:'s3',name:'Packed spares',unit:'packs',minutesPerUnit:6,batchUnits:150,setupHours:.25,productiveFraction:.88,hoursPer1000Sales:3.0,skill:'Packing'},
 {id:'PROD-D',department:'s4',name:'Formed component',unit:'pieces',minutesPerUnit:9,batchUnits:100,setupHours:.5,productiveFraction:.85,hoursPer1000Sales:4.5,skill:'Production'}
 ].map(p=>({...p,effectiveFrom:'2020-01-01',revision:1,evidence:'Fictional engineering standard; pooled daily batches, not a production routing.'}));
 const ds={schema:6,revision:1,source:'Fictional demand, output and department finance fixtures; not live ERP/payroll feeds.',products,records:[],performance:[],batches:[],audit:[],actions:[],receipts:[],costBenchmarks:{},shareAggregates:true,minCohort:5,benchmark:'ons-operators',market:[
 {id:'ons-all',label:'UK all workers · contextual reference',metric:'sicknessRate',value:2,unit:'percent_hours',start:'2025-01-01',end:'2025-12-31',cohort:'All UK workers',scope:'National; not matched manufacturing',source:'ons-2025',approved:true,proxy:true},
 {id:'ons-operators',label:'Process, plant & machine operatives',metric:'sicknessRate',value:3.3,unit:'percent_hours',start:'2025-01-01',end:'2025-12-31',cohort:'UK process, plant and machine occupations',scope:'Occupation across industries; not a manufacturing-sector average',source:'ons-2025',approved:true,proxy:true}
 ]};
 // Explicit zeros on weekend days allow closed days to be distinguished from missing records.
 for(let i=728;i>=1;i--){const date=add(NOW,-i),wd=dow(date);products.forEach((p,j)=>{
  const staff=s.staff.filter(x=>x.manager===p.department).length;const closed=wd===0||wd===6;
  const m=+date.slice(5,7);const seasonal=[.85,.91,.99,1.02,1.05,1.03,.94,.78,1.15,1.21,1.14,.88][m-1];
  const qty=closed?0:Math.round(([360,168,640,250][j])*seasonal*(.98+.06*Math.sin(i*.17+j))*(1+(728-i)*.0001));
  const sales=round(qty*[42,88,19,48][j]);const labour=closed?0:round(qty*p.minutesPerUnit/60+Math.ceil(qty/p.batchUnits)*p.setupHours);
  ds.records.push({record_id:`hist-${p.id}-${date}`,date,department:p.department,product:p.id,kind:'actual',quantity:qty,sales_amount:sales,actual_labour_hours:labour,currency:'GBP',unit:p.unit,revision:1,status:'active',source:'synthetic-fixture'});
  const scheduled=closed?0:round(staff*7.5),holiday=closed?0:round(scheduled*.035),eligible=scheduled-holiday;
  const lost=round(eligible*([.041,.023,.017,.031][j]+.003*Math.sin(i*.13+j)));
  const wages=round(scheduled*[25.5,22.5,20.2,23.7][j]*100),absencePay=round(lost*[24,21,19,22][j]*100),cover=round(lost*7.5*100);
  ds.performance.push({date,department:p.department,scheduledHours:scheduled,holidayHours:holiday,sicknessHours:lost,otherAbsenceHours:round(eligible*.003),paidSickPence:absencePay,incrementalCoverPence:cover,totalLabourPence:wages+cover,netSalesPence:Math.round(sales*100),headcount:staff,verified:true,source:'synthetic reviewed department finance fixture'});
 });}
 // Independent daily forecasts and firm orders; never summed as two copies of the same demand.
 for(let i=0;i<14;i++){const date=add(NOW,i);products.forEach((p,j)=>{const open=![0,6].includes(dow(date));const q=open?Math.round(([385,150,630,285][j])*(i>=7?1.13:1)):0;
 ds.records.push({record_id:`plan-${p.id}-${date}`,date,department:p.department,product:p.id,kind:'forecast',quantity:q,sales_amount:round(q*[42,88,19,48][j]),actual_labour_hours:null,currency:'GBP',unit:p.unit,revision:1,status:'active',source:'synthetic-fixture'});
 if(q)ds.records.push({record_id:`order-${p.id}-${date}`,date,department:p.department,product:p.id,kind:'order',quantity:Math.round(q*.76),sales_amount:round(Math.round(q*.76)*[42,88,19,48][j]),actual_labour_hours:null,currency:'GBP',unit:p.unit,revision:1,status:'active',source:'synthetic-fixture'});
 });}
 s.demandPlanning=ds;return s;
}
function productAt(s,id,date){return s.demandPlanning.products.filter(p=>p.id===id&&p.effectiveFrom<=date).sort((a,b)=>a.effectiveFrom.localeCompare(b.effectiveFrom)||a.revision-b.revision).at(-1);}
function cleanText(v,name,max=100){assert(typeof v==='string'&&v.trim().length>0&&v.length<=max&&!/[\x00-\x1f]/.test(v),name+' is required and must be plain text.');return v.trim();}
function number(v,name,nullable=false){if(v===''||v===null||v===undefined){assert(nullable,name+' is required.');return null;}assert(typeof v==='number'||typeof v==='string'&&/^\d+(\.\d+)?$/.test(v.trim()),name+' must be a plain non-negative number.');const n=Number(v);assert(Number.isFinite(n)&&n>=0&&n<=1e10,name+' is out of range.');return n;}
function normalise(s,row,source='manual'){
 const keys=['record_id','date','department','product','kind'];for(const k of keys)cleanText(row[k],k);
 assert(/^[A-Za-z0-9_.:-]{1,100}$/.test(row.record_id),'Record ID contains unsupported characters.');
 assert(C.validDate(row.date),'Use a real ISO date: YYYY-MM-DD.');
 assert(['actual','order','forecast'].includes(row.kind),'Kind must be actual, order or forecast.');
 assert(row.kind!=='actual'||row.date<currentLocalDate(),'Actual demand must be on a completed local date.');
 const p=productAt(s,row.product,row.date);assert(p&&p.department===row.department,'Product and department do not match a dated engineering standard.');
 assert((row.currency||'GBP')==='GBP','GBP only; convert currency explicitly before import.');
 assert(!row.unit||row.unit===p.unit,'Unit does not match this product; explicit conversion is required.');
 const quantity=number(row.quantity,'Quantity',true),sales=number(row.sales_amount,'Net sales amount',true);
 assert(quantity!==null||sales!==null,'Provide a quantity, sales amount, or both.');
 const rev=number(row.revision??1,'Revision');assert(Number.isInteger(rev)&&rev>=1,'Revision must be a positive integer.');
 const status=row.status||'active';assert(['active','cancelled'].includes(status),'Status must be active or cancelled.');
 assert(status!=='cancelled'||row.kind!=='actual','Actual history requires an explicit revision, not order cancellation.');
 return {record_id:row.record_id,date:row.date,department:row.department,product:row.product,kind:row.kind,quantity,sales_amount:sales,actual_labour_hours:number(row.actual_labour_hours,'Actual productive labour hours',true),currency:'GBP',unit:p.unit,revision:rev,status,source};
}
const identity=r=>r.department+'|'+r.record_id;
function fingerprint(r){return JSON.stringify(Object.fromEntries(Object.keys(r).filter(k=>k!=='source').sort().map(k=>[k,r[k]])));}
function validateRows(s,a,rows,source='manual'){
 access(s,a);assert(Array.isArray(rows)&&rows.length>0&&rows.length<=5000,'Supply 1–5,000 rows.');
 const allowed=new Set(departments(s,a).map(d=>d.id)),valid=[],errors=[],seen=new Set(),forecastDays=new Set();
 rows.forEach((row,i)=>{try{const r=normalise(s,row,source);assert(allowed.has(r.department),'Department is outside your authority.',403);const key=identity(r);assert(!seen.has(key),'Duplicate record ID within department in this batch.');seen.add(key);if(r.kind==='forecast'&&r.status==='active'){const fkey=r.product+'|'+r.date;assert(!forecastDays.has(fkey),'Only one total forecast per product/date is allowed in a batch.');forecastDays.add(fkey);const competing=s.demandPlanning.records.find(x=>x.kind==='forecast'&&x.status==='active'&&x.product===r.product&&x.date===r.date&&identity(x)!==key);assert(!competing,'A total forecast already exists for this product/date. Revise record '+(competing?.record_id||'')+' using a higher revision instead of adding another total.');}const old=s.demandPlanning.records.find(x=>identity(x)===key);if(old){assert(r.revision>=old.revision,'Stale source revision.');assert(r.revision!==old.revision||fingerprint(r)===fingerprint(old),'Changed record needs a higher source revision.');assert(r.kind===old.kind&&r.product===old.product,'Existing identity cannot change kind or product.');}valid.push(r);}catch(e){errors.push({line:i+2,message:e.message});}});
 return {valid,errors,canApply:!errors.length&&valid.length>0,rows:rows.length,source,rawFileRetained:false};
}
const FIELDS=['record_id','date','department','product','kind','quantity','sales_amount','currency','unit','revision','status','actual_labour_hours'];
function previewCSV(s,a,csv,mapping){access(s,a);assert(typeof csv==='string'&&csv.length<=1e6,'CSV limit is 1 MB.');const p=C.parseCSV(csv);const map=mapping||Object.fromEntries(FIELDS.map(k=>[k,p.headers.includes(k)?k:'']));
 const used=Object.values(map).filter(Boolean);assert(new Set(used).size===used.length,'Each source column can only be mapped once.');assert(used.every(k=>p.headers.includes(k)),'Mapped header not found.');
 const rows=p.rows.map(values=>Object.fromEntries(FIELDS.map(k=>[k,map[k]?values[p.headers.indexOf(map[k])]:''])));
 // Blank optional fields need defaults; absence of a field is not numeric zero.
 rows.forEach(r=>{for(const k of ['currency','revision','status','unit'])if(!r[k])delete r[k];});
 return {...validateRows(s,a,rows,'csv'),headers:p.headers,mapping:map,ignored:p.headers.filter(h=>!used.includes(h))};
}
function applyRows(s,a,rows,source){const p=validateRows(s,a,rows,source);assert(p.canApply,p.errors.map(e=>'Row '+e.line+': '+e.message).join(' '));let inserted=0,updated=0,unchanged=0;for(const r of p.valid){const i=s.demandPlanning.records.findIndex(x=>identity(x)===identity(r));if(i<0){s.demandPlanning.records.push(r);inserted++;}else if(fingerprint(s.demandPlanning.records[i])===fingerprint(r))unchanged++;else{s.demandPlanning.records[i]=r;updated++;}}s.demandPlanning.revision++;return {inserted,updated,unchanged,cancelled:p.valid.filter(r=>r.status==='cancelled').length};}
function windowBounds(kind,through='2026-09-13'){
 assert(['daily','weekly','monthly','yearly'].includes(kind),'Invalid comparison period.');assert(C.validDate(through)&&through<NOW,'Comparison must end on a completed date.');
 let start=kind==='yearly'?through.slice(0,4)+'-01-01':kind==='monthly'?through.slice(0,7)+'-01':kind==='weekly'?week(through):through;
 return {kind,start,end:through,label:`${start} – ${through}`,complete:kind==='daily'||kind==='weekly'&&dow(through)===0};
}
function performanceMetric(rows){
 const out={scheduledHours:0,eligibleHours:0,sicknessHours:0,otherAbsenceHours:0,paidSickPence:0,incrementalCoverPence:0,totalLabourPence:0,netSalesPence:0,records:rows.length,headcount:0};
 for(const r of rows){out.scheduledHours+=r.scheduledHours;out.eligibleHours+=r.scheduledHours-r.holidayHours;for(const k of ['sicknessHours','otherAbsenceHours','paidSickPence','incrementalCoverPence','totalLabourPence','netSalesPence'])out[k]+=r[k];}
 const counts=new Map();for(const r of rows)counts.set(r.department,Math.max(counts.get(r.department)||0,r.headcount));out.headcount=sum([...counts.values()]);
 out.absenceCostPence=out.paidSickPence+out.incrementalCoverPence;
 out.sicknessRate=ratio(out.sicknessHours,out.eligibleHours);out.absenceCostPct=ratio(out.absenceCostPence,out.totalLabourPence);out.labourSalesPct=ratio(out.totalLabourPence,out.netSalesPence);
 return Object.fromEntries(Object.entries(out).map(([k,v])=>[k,typeof v==='number'?round(v):v]));
}
function benchmarks(s,a,scope=a.personId,kind='weekly',through='2026-09-13'){
 decorate(s);const own=departments(s,a,scope),ids=new Set(own.map(x=>x.id)),bounds=windowBounds(kind,through),ds=s.demandPlanning;
 const rows=ds.performance.filter(r=>r.verified&&r.date>=bounds.start&&r.date<=bounds.end);
 const teams=s.org.filter(n=>s.staff.some(p=>p.manager===n.id));
 const expectedDays=Math.round((new Date(bounds.end)-new Date(bounds.start))/DAY)+1;
 const cohort=teams.map(d=>{const part=rows.filter(x=>x.department===d.id),metric=performanceMetric(part),complete=new Set(part.map(x=>x.date)).size===expectedDays;return {id:d.id,name:d.label,...metric,complete};});
 const suppressed=cohort.filter(x=>x.headcount<ds.minCohort||!x.complete);const share=ds.shareAggregates||a.role==='director';
 function redact(x){if(a.costs)return x;const r={...x};for(const k of Object.keys(r))if(k.endsWith('Pence')||['absenceCostPct','labourSalesPct'].includes(k))delete r[k];return r;}
 const peers=cohort.filter(d=>(share||ids.has(d.id))&&d.headcount>=ds.minCohort&&d.complete).map(x=>redact({...x,own:ids.has(x.id)}));
 // Suppress company totals if subtracting visible peers would expose a small suppressed department.
 const company=share&&!suppressed.length?redact(performanceMetric(rows)):null;
 const selected=redact(performanceMetric(rows.filter(r=>ids.has(r.department))));const ownComplete=cohort.filter(x=>ids.has(x.id)).every(x=>x.complete);if(!ownComplete){for(const k of ['sicknessRate','absenceCostPct','labourSalesPct'])if(k in selected)selected[k]=null;}selected.complete=ownComplete;
 const external=ds.market.find(x=>x.id===ds.benchmark&&x.approved)||null;
 const costReferences=a.costs?['absenceCostPct','labourSalesPct'].map(metric=>ds.market.find(x=>x.id===ds.costBenchmarks[metric]&&x.approved)).filter(Boolean):[];
 return {bounds,selected,company,peers,external,sources:SOURCES.slice(0,3),scope,shareAggregates:share,suppressed:suppressed.length,costReferences,marketCost:costReferences.length?costReferences:null,coverage:{expectedDays,complete:ownComplete},
 marketCostNote:'Public manufacturing cost comparisons have not been verified. Company-supplied references, where shown, require licensing and methodology review. Do not replace a cost ratio with the sickness percentage.',
 comparisonNote:'Annual 2025 external context, not a matched-period control or a performance target. Definitions, product mix and paid-cost coverage differ. Internal ratios use totals, not averages of percentages.',
 definition:'Sickness hours / (scheduled working hours less authorised holiday hours). Sick pay plus incremental cover / total employer labour cost. Employer labour cost / attributed net sales excluding VAT. Missing data is not zero.',source:ds.source};
}
function historical(s,product,before){
 const days=new Map();for(const r of s.demandPlanning.records.filter(r=>r.product===product&&r.kind==='actual'&&r.status==='active'&&r.date<before)){
  if(!days.has(r.date))days.set(r.date,{...r,quantity:0,sales_amount:0,actual_labour_hours:0});const d=days.get(r.date);
  for(const f of ['quantity','sales_amount','actual_labour_hours'])d[f]=d[f]===null||r[f]===null?null:d[f]+r[f];
 }return [...days.values()].sort((a,b)=>a.date.localeCompare(b.date));
}
function baseline(records,date,basis){
 const field=basis==='units'?'quantity':'sales_amount';const eligible=records.filter(r=>r.date<date&&r[field]!==null&&dow(r.date)===dow(date));
 const recent=eligible.slice(-8);if(recent.length<4)return {value:null,reason:'Need at least four completed same-weekday observations.',seasonal:false,n:recent.length};
 let value=sum(recent.map(r=>r[field]))/recent.length;let seasonal=false;
 const prevYear=records.filter(r=>r.date>=add(date,-378)&&r.date<=add(date,-350)&&r[field]!==null&&dow(r.date)===dow(date));
 const priorRecent=records.filter(r=>r.date>=add(date,-420)&&r.date<add(date,-364)&&r[field]!==null&&dow(r.date)===dow(date));
 const span=(new Date(date)-new Date(records[0]?.date))/DAY;
 if(span>=700&&prevYear.length>=3&&priorRecent.length>=6){const prev=sum(priorRecent.map(r=>r[field]))/priorRecent.length;const trend=prev?Math.max(.5,Math.min(1.5,value/prev)):1;value=(value+sum(prevYear.map(r=>r[field]))/prevYear.length*trend)/2;seasonal=true;}
 return {value:round(value),reason:'Trailing eight same weekdays'+(seasonal?' blended with prior-year window and capped trend.':'; insufficient two-year history for seasonal blend.'),seasonal,n:recent.length};
}
function demandFor(s,product,date,basis,mode='hybrid',change=0){
 const field=basis==='units'?'quantity':'sales_amount',rows=s.demandPlanning.records.filter(r=>r.product===product&&r.date===date&&r.status==='active');
 const orders=rows.filter(r=>r.kind==='order'),plans=rows.filter(r=>r.kind==='forecast');
 if(mode==='hybrid'&&plans.length>1)return {value:null,firm:null,forecast:null,additionalForecast:null,model:{reason:'Conflicting total forecasts: reconcile to one product/date snapshot.',n:0},source:'Forecast conflict',historyCount:0};
 if(mode!=='history'&&(orders.some(r=>r[field]===null)||mode==='hybrid'&&plans.some(r=>r[field]===null)))return {value:null,firm:null,forecast:null,additionalForecast:null,model:{reason:'A demand record lacks the selected basis. Supply units or a reviewed sales conversion.',n:0},source:'Incomplete demand basis',historyCount:historical(s,product,NOW).length};
 const firm=sum(orders.map(r=>r[field])),explicit=plans.length?sum(plans.map(r=>r[field])):null;
 const history=historical(s,product,NOW),model=baseline(history,date,basis);
 const forecast=explicit??model.value;const scenario=forecast===null?null:round(forecast*(1+change/100));
 const value=mode==='orders'?firm:mode==='history'?(model.value===null?null:round(model.value*(1+change/100))):scenario===null?(orders.length?firm:null):Math.max(firm,scenario);
 return {value,firm,forecast,additionalForecast:value===null?null:Math.max(0,value-firm),model,source:mode==='orders'?'firm remaining orders only':mode==='history'?'historical demand baseline':explicit!==null?'confirmed orders consumed against uploaded forecast':'confirmed orders consumed against historical baseline',historyCount:history.length};
}
function requiredHours(product,value,basis){if(value===null)return null;if(basis==='sales')return round(value/1000*product.hoursPer1000Sales);const productive=value*product.minutesPerUnit/60+(value>0?Math.ceil(value/product.batchUnits)*product.setupHours:0);return round(productive/product.productiveFraction);}
function shiftPaid(sh){return Math.max(0,(Date.parse(sh.end)-Date.parse(sh.start))/3600000-sum((sh.breaks||[]).filter(b=>!b.paid).map(b=>(Date.parse(b.end)-Date.parse(b.start))/3600000)));}
const paidDayBounds=new Map();
function paidOnDay(sh,date){if(!paidDayBounds.has(date)){if(paidDayBounds.size>5000)paidDayBounds.clear();paidDayBounds.set(date,[Date.parse(R.localResolve(date+'T00:00')),Date.parse(R.localResolve(add(date,1)+'T00:00'))]);}const bounds=paidDayBounds.get(date),start=Math.max(Date.parse(sh.start),bounds[0]),end=Math.min(Date.parse(sh.end),bounds[1]);if(end<=start)return 0;let ms=end-start;for(const b of sh.breaks||[])if(!b.paid)ms-=Math.max(0,Math.min(end,Date.parse(b.end))-Math.max(start,Date.parse(b.start)));return Math.max(0,ms/3600000);}
function capacity(s,a,scope,weekStart,repeat=true){
 const people=access(s,a,scope),ids=new Set(people.map(p=>p.id)),ledger=people.flatMap(p=>C.mergeLedger(s,p.id));let shifts=ledger.filter(r=>C.localDay(r.end)>=weekStart&&C.localDay(r.start)<add(weekStart,7));let synthetic=false;
 if(!shifts.length&&repeat&&weekStart!==NOW){synthetic=true;const days=Math.round((new Date(weekStart)-new Date(NOW))/DAY);shifts=ledger.filter(r=>C.localDay(r.start)>=NOW&&C.localDay(r.start)<add(NOW,7)).map(r=>{const shift=t=>new Date(Date.parse(t)+days*DAY).toISOString();return {...r,id:'draft-'+r.id,start:shift(r.start),end:shift(r.end),kind:'draft',breaks:(r.breaks||[]).map(b=>({...b,start:shift(b.start),end:shift(b.end)}))};});}
 const days=[];
 const bills=new Map();for(const p of people){const ps=shifts.filter(x=>x.employee===p.id);if(ps.length){const prior=weekStart>NOW?ledger.filter(x=>x.employee===p.id&&C.localDay(x.start)>=NOW&&C.localDay(x.end)<weekStart):[];bills.set(p.id,R.priceSeries(s,p.id,[...prior,...ps]));}}
 for(let i=0;i<7;i++){const date=add(weekStart,i),byDept=[];for(const d of departments(s,a,scope)){
  const staff=people.filter(p=>p.manager===d.id),staffIds=new Set(staff.map(x=>x.id));const segments=[];let complete=true,issues=[];
  for(const p of staff){const b=bills.get(p.id);if(!b)continue;if(!b.complete){complete=false;issues.push(...b.issues.map(x=>x.reason||x.detail||'Cost evidence missing'));}segments.push(...b.rows.filter(x=>x.date===date));}
  let unavailableHours=0;
  for(const employee of staff){const ownShifts=shifts.filter(x=>x.employee===employee.id),paid=sum(ownShifts.map(sh=>paidOnDay(sh,date)));
   if(date===NOW&&employee.sick){unavailableHours+=paid;continue;}
   const leave=s.requests.filter(r=>r.employee===employee.id&&r.status==='approved'&&r.date===date);
   // Hours-based approved requests remove only their verified paid hours. Exact interval
   // placement still needs an operational check; do not make a part-day leave a full day.
   unavailableHours+=Math.min(paid,sum(leave.map(r=>Math.max(0,Number(r.hours)||0))));
  }
  const total=C.sumRows(segments),scheduledPaid=sum(shifts.filter(x=>staffIds.has(x.employee)).map(sh=>paidOnDay(sh,date)));byDept.push({department:d.id,paidHours:round(scheduledPaid),availableHours:round(Math.max(0,scheduledPaid-unavailableHours)),unavailableHours:round(unavailableHours),totalPence:complete?total.totalPence:null,premiumPence:complete?total.overtimePremiumPence+total.otherPremiumPence:null,complete,issues:[...new Set(issues)],draft:synthetic});
 }days.push({date,departments:byDept});}
 return {days,draft:synthetic,missing:!shifts.length,note:synthetic?'Draft: repeats this week’s costed roster and carries current-week planned hours into annual balances. Not a published or validated future rota.':shifts.length?'Existing costed roster; known leave/sickness reduces working capacity, not wage commitments.':'No scheduled capacity evidence. Zero is not a staffing recommendation.'};
}
function backtest(records,basis){const tests=records.filter(r=>![0,6].includes(dow(r.date))).slice(-20);if(tests.length<20||records.length<70)return {available:false,reason:'At least 70 completed demand days needed.'};const field=basis==='units'?'quantity':'sales_amount';let loss=0,total=0,n=0;for(const r of tests){if(r[field]===null)continue;const pred=baseline(records.filter(x=>x.date<r.date),r.date,basis);if(pred.value===null)continue;loss+=Math.abs(pred.value-r[field]);total+=r[field];n++;}return {available:n>0&&total>0,wape:total?round(100*loss/total):null,n,method:'Rolling-origin same-weekday baseline. Test records and later data are excluded from each training window; uploaded future orders are not in this score.'};}
function plan(s,a,scope=a.personId,options={}){
 decorate(s);access(s,a,scope);assert(a.costs,'Labour cost and demand planning permission required.',403);
 const basis=options.basis||'units',mode=options.mode||'hybrid',change=Number(options.change||0),horizon=options.horizon||'current';
 assert(['units','sales'].includes(basis),'Choose units or sales.');assert(['hybrid','orders','history'].includes(mode),'Invalid demand mode.');assert(['current','next'].includes(horizon),'Choose current or next week.');assert(Number.isFinite(change)&&change>=-80&&change<=200,'Scenario change must be between -80% and +200%.');
 const start=add(NOW,horizon==='next'?7:0),ds=s.demandPlanning,dept=departments(s,a,scope),ids=new Set(dept.map(d=>d.id));
 const products=ds.products.filter(p=>ids.has(p.department)&&productAt(s,p.id,start)===p),cap=capacity(s,a,scope,start,options.repeat!==false),daily=[];
 for(let i=0;i<7;i++){const date=add(start,i);const parts=products.map(p=>{const dated=productAt(s,p.id,date),d=demandFor(s,p.id,date,basis,mode,change);return {product:p.id,name:p.name,department:p.department,unit:p.unit,...d,requiredHours:requiredHours(dated,d.value,basis)};});
  const group=dept.map(d=>{const x=parts.filter(p=>p.department===d.id),c=cap.days[i].departments.find(x=>x.department===d.id);const complete=x.every(x=>x.requiredHours!==null);const need=complete?round(sum(x,'requiredHours')):null;return {...c,name:d.label,requiredHours:need,gapHours:need===null||cap.missing?null:round(Math.max(0,need-c.availableHours)),spareHours:need===null||cap.missing?null:round(Math.max(0,c.availableHours-need)),parts:x};});
  daily.push({date,groups:group,requiredHours:group.some(x=>x.requiredHours===null)?null:round(sum(group,'requiredHours')),capacityHours:cap.missing?null:round(sum(group,'availableHours')),costPence:cap.missing||group.some(x=>x.totalPence===null)?null:sum(group,'totalPence'),premiumPence:cap.missing||group.some(x=>x.premiumPence===null)?null:sum(group,'premiumPence')});
 }
 const parts=daily.flatMap(x=>x.groups.flatMap(x=>x.parts)),totalByProduct=products.map(p=>({product:p.id,name:p.name,unit:p.unit,value:parts.filter(x=>x.product===p.id).some(x=>x.value===null)?null:round(sum(parts.filter(x=>x.product===p.id),'value'))}));
 for(const product of totalByProduct){const pd=products.find(x=>x.id===product.product);const groups=daily.map(x=>x.groups.find(g=>g.department===pd.department));product.costPerUnitPence=basis==='units'&&product.value>0&&products.filter(x=>x.department===pd.department).length===1&&groups.every(g=>g.totalPence!==null)?Math.round(sum(groups,'totalPence')/product.value):null;}
 const complete=daily.every(d=>d.requiredHours!==null&&d.costPence!==null&&d.capacityHours!==null);
 const required=daily.every(d=>d.requiredHours!==null)?round(sum(daily,'requiredHours')):null,cost=daily.every(d=>d.costPence!==null)?sum(daily,'costPence'):null;
 const demandValue=totalByProduct.every(p=>p.value!==null)?round(sum(totalByProduct,'value')):null;
 const sales=basis==='sales'?demandValue:null;
 const actions=[];
 for(const d of dept){const groups=daily.map(x=>x.groups.find(g=>g.department===d.id));if(groups.some(g=>g.requiredHours===null||g.gapHours===null||g.spareHours===null))continue;const gap=round(sum(groups,'gapHours')),spare=round(sum(groups,'spareHours'));const premiums=groups.some(g=>g.premiumPence===null)?null:sum(groups,'premiumPence');
  if(spare>1)actions.push({id:`${start}-${d.id}-redeploy`,department:d.id,title:`Use ${spare} spare paid hours in ${d.label}`,kind:'capacity',hours:spare,cashSavingPence:0,detail:'Review training, maintenance or compatible due work in the specific spare intervals. Contracted wage commitments remain; this is capacity recovery, not a wage saving.',requires:['Skill and interval match','Receiving manager approval','No change to guaranteed pay']});
  if(gap>1)actions.push({id:`${start}-${d.id}-cover`,department:d.id,title:`Resolve ${gap} hours of uncovered demand in ${d.label}`,kind:'coverage',hours:gap,cashSavingPence:null,detail:'Review same-time, appropriately qualified available workers before premium or agency cover. The weekly total is not proof that labour can move across days or jobs.',requires:['Current availability and acceptance','Full shift/pay-week quote','Rest, qualifications and customer due dates']});
  if(premiums>0)actions.push({id:`${start}-${d.id}-premium`,department:d.id,title:`Review ${d.label} premium exposure`,kind:'premium',exposurePence:premiums,cashSavingPence:null,detail:'Premiums are a review opportunity, not automatically removable spend. Do not cancel accepted work, bank-holiday premiums or committed overtime to realise an assumed saving.',requires:['Identify uncommitted cover first','Check contract and notice','Reprice the complete pay week']});
 }
 // Reuse the existing exact cost and eligibility engine for today's real demonstration gap.
 if(horizon==='current')for(const gap of s.gaps.filter(g=>E.allowedPeople(s,a,scope).some(p=>p.id===g.employee))){try{const alternatives=C.alternatives(s,a,gap.id),eligible=alternatives.candidates.filter(x=>x.costEligible&&x.quote).sort((x,y)=>x.quote.incremental.totalPence-y.quote.incremental.totalPence);const best=eligible[0],premium=eligible.find(x=>x.quote.premiumRequired&&x.quote.incremental.totalPence>best.quote.incremental.totalPence);if(best&&premium)actions.unshift({id:`${start}-${gap.id}-substitute`,department:s.staff.find(p=>p.id===gap.employee).manager,kind:'cover-quote',title:`Review ${best.name} before the higher-cost cover option`,cashSavingPence:premium.quote.incremental.totalPence-best.quote.incremental.totalPence,detail:`Conditional comparison: ${best.name} versus ${premium.name} for the same gap; full-week additional cost. Neither assignment nor saving is confirmed.`,gap:gap.id,requires:['Recheck availability and skills','Employee acceptance','Manager confirmation']});}catch{}}
 actions.sort((a,b)=>({ 'cover-quote':0,coverage:1,premium:2,capacity:3}[a.kind]-{ 'cover-quote':0,coverage:1,premium:2,capacity:3}[b.kind])||((b.cashSavingPence||b.exposurePence||b.hours||0)-(a.cashSavingPence||a.exposurePence||a.hours||0)));
 const historyCounts=products.map(p=>{const h=historical(s,p.id,NOW);return {product:p.id,n:h.length,validation:backtest(h,basis)};});
 return {scope,start,end:add(start,6),horizon,basis,mode,change,currency:'GBP',daily,products:totalByProduct,complete,requiredHours:required,capacityHours:daily.every(d=>d.capacityHours!==null)?round(sum(daily,'capacityHours')):null,totalCostPence:cost,premiumPence:daily.every(d=>d.premiumPence!==null)?sum(daily,'premiumPence'):null,labourSalesPct:cost!==null&&sales!==null?ratio(cost,sales*100):null,draft:cap.draft,capacityNote:cap.note,actions:actions.map(x=>({...x,status:ds.actions.find(y=>y.id===x.id)?.status||'proposed'})),history:historyCounts,overdueOrders:ds.records.filter(r=>r.kind==='order'&&r.status==='active'&&r.date<NOW&&ids.has(r.department)).length,
 notes:['Orders represent remaining unfulfilled demand, not original quantities. Hybrid = max(confirmed orders, forecast total) per product/day, not their sum.','Production mode uses each product’s engineering standard, pooled daily batch setup and productive-time allowance. Mixed units are never presented as one production total.','Sales mode uses explicit hours per £1,000 net sales; this is a coarse calibrated workload proxy, sensitive to price and product mix.','Actual demand records are separate from attendance. No forecast is trained on future outcomes. Historical backtesting is not accuracy evidence for uploaded future orders.','Cost is the existing or draft roster including effective pay rates and contractual premiums. Missing people are not priced automatically; additional hires/agency/cover are not in the committed cost.','Approved part-day leave reduces paid capacity hours; exact within-day positioning requires the manager to check the affected intervals. Current-week reports include elapsed and future time; no past shift is an actionable saving.','Roster cost per forecast unit is displayed only where a department has one product; it is not actual manufacturing unit costing or a marginal cost.','No machine/material capacity, production routing, inventory allocation or job-level scheduling solver is connected. Recommendations need human review.'],source:ds.source};
}
function settings(s,a){decorate(s);const ids=new Set(departments(s,a).map(x=>x.id));return {revision:s.demandPlanning.revision,departments:departments(s,a),products:s.demandPlanning.products.filter(p=>ids.has(p.department)),forecastKeys:s.demandPlanning.records.filter(r=>r.kind==='forecast'&&r.status==='active'&&ids.has(r.department)&&r.date>=NOW).map(r=>({record_id:r.record_id,product:r.product,date:r.date,revision:r.revision})),market:s.demandPlanning.market,costBenchmarks:s.demandPlanning.costBenchmarks,benchmark:s.demandPlanning.benchmark,configure:canConfigure(a),recordCount:s.demandPlanning.records.filter(r=>ids.has(r.department)).length,historyCount:s.demandPlanning.records.filter(r=>ids.has(r.department)&&r.kind==='actual').length,sources:SOURCES};}
function dispatch(s,a,cmd,p){decorate(s);access(s,a);let out;
 switch(cmd){
 case 'demand-stage':{assert(a.costs,'Cost permission required for demand import.',403);const v=p.csv?previewCSV(s,a,p.csv,p.mapping):validateRows(s,a,p.rows,'manual');assert(v.canApply,v.errors.map(x=>`Row ${x.line}: ${x.message}`).join(' '));const id='demand-'+s.version+'-'+s.demandPlanning.batches.length;const b={id,actor:a.personId,version:s.version+1,status:'staged',rows:v.valid,source:v.source};s.demandPlanning.batches.push(b);if(s.demandPlanning.batches.length>20)s.demandPlanning.batches.shift();out={id,preview:v};break;}
 case 'demand-apply':{assert(a.costs,'Cost permission required.',403);assert(p.reviewed===true,'Review the demand import before applying.');const b=s.demandPlanning.batches.find(x=>x.id===p.id);assert(b&&b.actor===a.personId,'Staged import not found.',404);assert(b.status==='staged'&&b.version===s.version,'The data changed; validate and stage again.',409);out={id:b.id,...applyRows(s,a,b.rows,b.source)};b.status='applied';b.count=b.rows.length;delete b.rows;break;}
 case 'demand-action':{assert(['reviewed','dismissed'].includes(p.status),'Invalid recommendation outcome.');const report=plan(s,a,p.scope||a.personId,p.options||{});assert(report.actions.some(x=>x.id===p.id),'Current recommendation not found; refresh before reviewing.',409);const note=cleanText(p.reason,'Review reason',300);s.demandPlanning.actions=s.demandPlanning.actions.filter(x=>x.id!==p.id);s.demandPlanning.actions.push({id:p.id,status:p.status,reason:note,by:a.personId});out={id:p.id,status:p.status};break;}
 case 'demand-standard':{assert(canConfigure(a),'Company configuration permission required.',403);const old=productAt(s,p.product,NOW);assert(old,'Product not found.');const allowed=['effectiveFrom','minutesPerUnit','batchUnits','setupHours','productiveFraction','hoursPer1000Sales'];assert(p.standard&&Object.keys(p.standard).every(k=>allowed.includes(k)),'Unsupported engineering field.');const v={...old,...p.standard,id:old.id,department:old.department,revision:Math.max(...s.demandPlanning.products.filter(x=>x.id===old.id).map(x=>x.revision))+1};assert(C.validDate(v.effectiveFrom)&&v.effectiveFrom>=NOW,'A new standard must start today or later.');for(const key of ['minutesPerUnit','batchUnits','productiveFraction','hoursPer1000Sales']){v[key]=number(v[key],key);assert(v[key]>0,key+' must be greater than zero.');}v.setupHours=number(v.setupHours,'Setup hours');assert(v.productiveFraction<=1&&v.minutesPerUnit<=60000&&v.setupHours<=100,'Engineering standard is out of range.');v.evidence=cleanText(p.reason,'Engineering evidence',300);s.demandPlanning.products.push(v);s.demandPlanning.revision++;out={id:v.id};break;}
 case 'demand-benchmark-add':{
 assert(canConfigure(a),'Company configuration permission required.',403);assert(p.reviewed===true,'Review the source methodology and permission to use it.');
 const metric=p.metric;assert(['sicknessRate','absenceCostPct','labourSalesPct'].includes(metric),'Unknown benchmark metric.');const value=number(p.value,'Benchmark percentage');assert(value<=(metric==='labourSalesPct'?10000:100),'Benchmark percentage out of range.');
 assert(C.validDate(p.start)&&C.validDate(p.end)&&p.end>=p.start&&p.end<NOW,'Benchmark must cover a completed dated period.');
 const url=cleanText(p.url,'Source URL',800);assert(/^https:\/\/[^\s]+$/.test(url),'Use an HTTPS source URL.');
 const id='company-reference-'+s.version+'-'+s.demandPlanning.market.length,label=cleanText(p.label,'Reference label',120),cohort=cleanText(p.cohort,'Cohort',200),method=cleanText(p.method,'Methodology',400);
 const entry={id,label,metric,value,start:p.start,end:p.end,cohort,method,unit:metric==='sicknessRate'?'percent_hours':'percent_cost',scope:'Company-supplied reference; comparability must be reviewed',source:'company-reviewed',sourceUrl:url,approved:true,proxy:true,reviewedBy:a.personId,reviewedAt:E.AS_OF,verification:'Not independently verified by this application'};s.demandPlanning.market.push(entry);if(metric==='sicknessRate')s.demandPlanning.benchmark=id;else s.demandPlanning.costBenchmarks[metric]=id;out={id};break;
 }
 case 'demand-benchmark':{assert(canConfigure(a),'Company configuration permission required.',403);assert(s.demandPlanning.market.some(x=>x.id===p.id&&x.approved),'Unknown approved reference.');s.demandPlanning.benchmark=p.id;out={id:p.id};break;}
 default:assert(false,'Unknown demand command.',404);
 }
 E.audit(s,a,cmd,null,out.id);s.demandPlanning.audit.push({action:cmd,by:a.personId,at:E.AS_OF,id:out.id});return out;
}
const api={NOW,SOURCES,FIELDS,decorate,departments,access,normalise,validateRows,previewCSV,applyRows,fingerprint,identity,productAt,windowBounds,performanceMetric,benchmarks,historical,baseline,demandFor,requiredHours,paidOnDay,capacity,backtest,plan,settings,dispatch};
if(typeof module!=='undefined')module.exports=api;root.WFMDemand=api;
})(typeof globalThis!=='undefined'?globalThis:this);
