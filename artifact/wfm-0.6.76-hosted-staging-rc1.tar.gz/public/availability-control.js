/* Reviewed availability intervals. Independent of optional overtime interest and payroll. */
(function(root){'use strict';
const DAY=86400000,MAX=20000;
const engine=()=>typeof module!=='undefined'&&module.exports?require('./engine.js'):root.WFMEngine;
function assert(ok,message,status=400){if(!ok)throw Object.assign(new Error(message),{status});}
const copy=x=>JSON.parse(JSON.stringify(x));
function instant(value){
 assert(typeof value==='string'&&/^\d{4}-\d\d-\d\dT(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d(?:\.\d{1,3})?)?(Z|[+-]\d\d:\d\d)$/.test(value),'Use a timestamp with an explicit UTC offset.');
 const day=value.slice(0,10),n=Date.parse(value);assert(Number.isFinite(n)&&day>='2000-01-01'&&day<='2099-12-31'&&new Date(Date.parse(day+'T12:00:00Z')).toISOString().slice(0,10)===day,'Invalid calendar timestamp.');return n;
}
function interval(x){const start=instant(x.start),end=instant(x.end);assert(end>start&&end-start<=366*DAY,'Availability must be positive and at most 366 elapsed days.');return {start,end};}
function records(s){const c=s.availabilityControl;if(c===undefined)return [];assert(c&&c.schema===1&&Array.isArray(c.records)&&c.records.length<=MAX,'Availability evidence needs reconciliation.',409);return c.records;}
function access(s,a,id){const E=engine();assert(a&&['employee','manager','director','supervisor'].includes(a.role),'Operational access is required.',403);const people=E.allowedPeople(s,a);if(id)assert(people.some(p=>p.id===id),'Employee outside your reporting scope.',403);return people;}
function manager(s,a,id){access(s,a,id);assert(a.role!=='employee'&&a.personId!==id,'Independent manager review is required.',403);}
function reason(x){assert(typeof x==='string'&&x.trim().length>=8&&x.trim().length<=400,'Record a reason of 8–400 characters without medical details.');return x.trim();}
function current(now){const n=typeof now==='number'?now:Date.parse(now);assert(Number.isFinite(n),'Server time is invalid.',409);return n;}
function localDay(n){return new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/London',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(n));}
function siteAllowed(s,id,site,from,to){const p=s.staff.find(p=>p.id===id);return p?.site===site||(s.operations?.siteAccess?.[id]||[]).some(r=>r.site===site&&r.approved===true&&r.validFrom<=localDay(from)&&r.validUntil>=localDay(to-1));}
function evaluate(s,id,shift){
 let span;try{span=interval(shift);}catch{return {status:'invalid',blocking:true,confirmed:false,recordIds:[],detail:'The assignment interval is invalid.'};}
 let rows;try{rows=records(s);}catch{return {status:'invalid',blocking:true,confirmed:false,recordIds:[],detail:'Availability evidence needs reconciliation.'};}
 const active=[];
 for(const r of rows.filter(r=>r.employee===id&&r.status==='approved')){
  try{const t=interval(r);assert(['available','unavailable'].includes(r.kind),'Unknown kind');assert(r.kind==='unavailable'?r.site==='*':typeof r.site==='string'&&r.site!=='*','Invalid site');if(t.start<span.end&&t.end>span.start)active.push({...t,record:r});}
  catch{return {status:'invalid',blocking:true,confirmed:false,recordIds:[],detail:'Approved availability evidence is invalid; reconcile before assigning.'};}
 }
 const blocked=active.filter(r=>r.record.kind==='unavailable');
 if(blocked.length)return {status:'unavailable',blocking:true,confirmed:false,recordIds:blocked.map(r=>r.record.id),detail:'Approved unavailability overlaps the proposed work. Review the restriction before assigning.'};
 const slots=active.filter(r=>r.record.kind==='available'&&r.record.site===shift.site).sort((a,b)=>a.start-b.start||a.end-b.end);
 let cursor=span.start;for(const r of slots){if(r.start>cursor)break;cursor=Math.max(cursor,r.end);}
 const confirmed=cursor>=span.end;
 return {status:confirmed?'confirmed':'unknown',blocking:false,confirmed,recordIds:slots.map(r=>r.record.id),detail:confirmed?'Reviewed availability covers the complete interval; consent and other assignment checks still apply.':'No complete reviewed availability record. Existing contract, optional-interest and consent checks still apply.'};
}
function commit(s,a,action,row,now){
 if(!s.availabilityControl)s.availabilityControl={schema:1,revision:0,records:[],audit:[]};
 const c=s.availabilityControl;c.revision++;c.audit.push({id:row.id,revision:row.revision,action,by:a.personId,at:new Date(current(now)).toISOString(),status:row.status,reason:action==='submit'?row.reason:row.decisionReason});
 engine().audit(s,a,'availability-control-'+action,row.employee,'Reviewed availability record '+row.id+' is '+row.status+'. Published work and payroll are unchanged.');
 return copy(row);
}
function submit(s,a,x,now=Date.now()){
 const id=a.role==='employee'?a.personId:x.employee;access(s,a,id);assert(id&&s.staff.some(p=>p.id===id),'Employee not found.',404);assert(a.role!=='employee'||x.employee===undefined||x.employee===id,'Employees may submit only their own availability.',403);
 const rows=records(s),span=interval(x),at=current(now),why=reason(x.reason);assert(span.start>at&&span.start<=at+2*366*DAY,'Choose a future start within two years.');assert(['available','unavailable'].includes(x.kind),'Choose available or unavailable.');
 const site=x.kind==='unavailable'?'*':x.site;assert(x.kind==='unavailable'||siteAllowed(s,id,site,span.start,span.end),'Current site approval must cover the complete availability interval.',409);
 assert(rows.length<MAX,'Archive reviewed availability history before adding more records.',409);
 assert(!rows.some(r=>r.employee===id&&r.kind===x.kind&&r.site===site&&['pending','approved'].includes(r.status)&&Date.parse(r.start)===span.start&&Date.parse(r.end)===span.end),'An active record already covers this exact interval.',409);
 const row={id:'avc-'+s.version+'-'+(rows.length+1),employee:id,kind:x.kind,site,start:new Date(span.start).toISOString(),end:new Date(span.end).toISOString(),status:'pending',revision:1,submittedBy:a.personId,submittedAt:new Date(at).toISOString(),reason:why};
 // No mutation until every input and permission check passed.
 if(!s.availabilityControl)s.availabilityControl={schema:1,revision:0,records:[],audit:[]};s.availabilityControl.records.push(row);return commit(s,a,'submit',row,now);
}
function decide(s,a,x,now=Date.now()){
 const rows=records(s),row=rows.find(r=>r.id===x.id);assert(row,'Availability request not found.',404);access(s,a,row.employee);assert(Number.isInteger(x.revision)&&x.revision===row.revision,'Availability request changed. Refresh before deciding.',409);
 const why=reason(x.reason),at=current(now);assert(['approve','reject','withdraw','revoke'].includes(x.decision),'Unknown availability decision.');
 if(x.decision==='withdraw'){assert(row.status==='pending'&&row.submittedBy===a.personId,'Only the submitter can withdraw a pending request.',403);}
 else{manager(s,a,row.employee);assert(row.submittedBy!==a.personId,'The submitting manager cannot approve or reject their own request.',403);assert(x.decision==='revoke'?row.status==='approved':row.status==='pending','Availability request is already final.',409);}
 if(x.decision==='approve'){const t=interval(row);assert(t.end>at,'Expired availability cannot be approved.',409);assert(row.kind==='unavailable'||siteAllowed(s,row.employee,row.site,t.start,t.end),'Site approval changed before review.',409);}
 const status={approve:'approved',reject:'rejected',withdraw:'withdrawn',revoke:'revoked'}[x.decision];Object.assign(row,{status,revision:row.revision+1,decidedBy:a.personId,decidedAt:new Date(at).toISOString(),decisionReason:why});return commit(s,a,x.decision,row,now);
}
function report(s,a){
 const people=access(s,a),ids=new Set(people.map(p=>p.id)),rows=records(s).filter(r=>ids.has(r.employee)),conflicts=[];
 for(const sh of s.workRules?.roster||[]){if(!ids.has(sh.employee)||sh.cancelled||sh.published===false)continue;const v=evaluate(s,sh.employee,sh);if(v.blocking)conflicts.push({shiftId:sh.id,employee:sh.employee,start:sh.start,end:sh.end,site:sh.site||people.find(p=>p.id===sh.employee)?.site,status:v.status,recordIds:v.recordIds});}
 return {schema:1,sourceVersion:s.version,revision:s.availabilityControl?.revision||0,people:people.map(p=>({id:p.id,name:p.name,site:p.site,sites:[...new Set([p.site,...(s.operations?.siteAccess?.[p.id]||[]).filter(x=>x.approved).map(x=>x.site)])]})),records:rows.map(r=>({...copy(r),canWithdraw:r.status==='pending'&&r.submittedBy===a.personId,canReview:a.role!=='employee'&&a.personId!==r.employee&&r.submittedBy!==a.personId&&['pending','approved'].includes(r.status)})),conflicts,notice:'Pending requests do not change the rota. Approved unavailability blocks new assignments and flags existing work for review. Optional overtime interest remains separate.'};
}
function dispatch(s,a,name,x,now=Date.now()){if(name==='availability-submit')return submit(s,a,x,now);if(name==='availability-decide')return decide(s,a,x,now);assert(false,'Unknown availability command.',400);}
const api={instant,interval,evaluate,submit,decide,report,dispatch};root.WFMAvailability=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
