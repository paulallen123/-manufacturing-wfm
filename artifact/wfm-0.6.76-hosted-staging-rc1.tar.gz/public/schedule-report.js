/* Read-only planned roster report. This is not payroll or a general data export. */
(function(root){'use strict';
const E=typeof module!=='undefined'?require('./engine.js'):root.WFMEngine;
const DAY=86400000,MAX_ROWS=10000;
const HEADERS=['Shift ID','Revision','Publication ID','Employee ID','Employee','Site','Department ID','Job','Start UTC','End UTC','Record type','Source version'];
function day(value){
 E.assert(typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value),'Use an ISO calendar date (YYYY-MM-DD).');
 const ms=Date.parse(value+'T00:00:00Z');
 E.assert(Number.isFinite(ms)&&new Date(ms).toISOString().slice(0,10)===value&&Number(value.slice(0,4))>=2000&&Number(value.slice(0,4))<=2099,'Report dates must be valid calendar dates from 2000 to 2099.');
 return ms;
}
function cell(value){
 let str=String(value??'');
 // A visible text marker avoids relying on spreadsheet-specific apostrophe handling.
 // All separators and quotes remain inside one CSV field. Source data is unchanged.
 if(/^[\s\p{Cf}\u0000-\u001f]*[=+\-@＝＋－＠]/u.test(str)||/^[\s\p{Cf}\u0000-\u001f]*[\t\r\n]/u.test(str))str='[text] '+str;
 return '"'+str.replaceAll('"','""')+'"';
}
function report(s,a,options={}){
 E.assert(a&&['employee','manager','director','supervisor'].includes(a.role),'Schedule export access required.',403);
 const scope=options.scope||a.personId,people=E.allowedPeople(s,a,scope),byId=new Map(people.map(p=>[p.id,p]));
 const from=day(options.from),to=day(options.to);
 E.assert(to>=from&&to-from<366*DAY,'Choose an inclusive range of 1 to 366 days.');
 const start=Date.parse(E.resolveLondon(options.from+'T00:00')),next=new Date(to+DAY).toISOString().slice(0,10),end=Date.parse(E.resolveLondon(next+'T00:00'));
 const shifts=(s.workRules?.roster||[]).filter(sh=>byId.has(sh.employee)&&!sh.cancelled&&sh.published!==false&&sh.kind!=='draft');
 const selected=[];
 for(const sh of shifts){
  const x=Date.parse(sh.start),y=Date.parse(sh.end);
  E.assert(Number.isFinite(x)&&Number.isFinite(y)&&y>x&&/(Z|[+-]\d{2}:\d{2})$/.test(sh.start)&&/(Z|[+-]\d{2}:\d{2})$/.test(sh.end),'A visible roster record has an invalid interval. Correct it before exporting.',409);
  if(x<end&&y>start)selected.push(sh);
 }
 E.assert(selected.length<=MAX_ROWS,'This report exceeds 10,000 rows. Select a shorter period or smaller team.',413);
 selected.sort((a,b)=>Date.parse(a.start)-Date.parse(b.start)||String(a.employee).localeCompare(String(b.employee))||String(a.id).localeCompare(String(b.id)));
 const rows=selected.map(sh=>{const p=byId.get(sh.employee);return [sh.id,sh.revision||1,sh.publicationId||'',p.id,p.name,sh.site||p.site,sh.department||p.manager,sh.job||p.job,new Date(sh.start).toISOString(),new Date(sh.end).toISOString(),'Planned roster; not payroll',s.version];});
 return {schema:'schedule-report-1',filename:`published-schedule-${options.from}-to-${options.to}.csv`,sourceVersion:s.version,scope,from:options.from,to:options.to,timeZone:'Europe/London',rowCount:rows.length,notice:'Planned roster, not worked time or payroll. Dates select overlapping shifts in Europe/London; timestamps are UTC. Potential formula text is prefixed with [text].',csv:[HEADERS,...rows].map(row=>row.map(cell).join(',')).join('\r\n')+'\r\n'};
}
const api={report};if(typeof module!=='undefined')module.exports=api;root.WFMScheduleReport=api;
})(typeof globalThis!=='undefined'?globalThis:this);
