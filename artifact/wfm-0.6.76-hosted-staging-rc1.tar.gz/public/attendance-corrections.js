/* CORE-01: evidence-backed attendance requests. Extends the existing weekly payroll
 * records; never maintains a second authoritative timesheet. Server commits the
 * state, audit and in-app notification intent in one SQLite transaction. */
(function(root){
'use strict';
const E=typeof module!=='undefined'?require('./engine.js'):root.WFMEngine;
const P=typeof module!=='undefined'?require('./payroll-control.js'):root.WFMPayroll;
const clone=x=>JSON.parse(JSON.stringify(x));
const assert=E.assert;
const OPEN=['submitted','information_required','awaiting_approval','payroll_review_required'];
const MANAGERS=['manager','supervisor','director'];
function decorate(s){s.attendanceCorrections=s.attendanceCorrections||{requests:[],notifications:[],receipts:[]};return s;}
function fingerprint(r){return P.canonical({sourceVersion:r.sourceVersion,raw:r.raw,correction:r.correction||null});}
function note(value){assert(typeof value==='string'&&value.trim().length>=12&&value.length<=500,'Provide an evidence-based explanation of 12–500 characters.');return value.trim();}
function canSee(s,a,employee){return (a.role==='employee'||MANAGERS.includes(a.role))&&E.allowedPeople(s,a).some(p=>p.id===employee);}
function record(s,a,periodId,rowId){const p=P.period(s,periodId),r=p.records.find(r=>r.id===rowId);assert(r&&canSee(s,a,r.employee),'Attendance record not found in your authorised scope.',404);return {p,r,t:P.group(p,r.team)};}
function request(s,a,id){decorate(s);const q=s.attendanceCorrections.requests.find(q=>q.id===id);assert(q&&canSee(s,a,q.employee),'Correction request not found in your authorised scope.',404);return q;}
function manager(s,a,q){assert(MANAGERS.includes(a.role),'Operational manager access required.',403);assert(a.personId!==q.employee,'You cannot decide a correction to your own attendance.',403);const ctx=record(s,a,q.period,q.record);P.reviewer(s,a,ctx.p,ctx.t);return ctx;}
function checkRevision(q,x){assert(Number.isInteger(x.revision)&&x.revision===q.revision,'This correction changed. Refresh before continuing.',409);}
// Avoid computing a signed snapshot without its full state.
function payrollLocked(s,p,t){return ['signed','stale'].includes(P.stateOf(s,p,t))||p.batches.some(b=>['released','sent'].includes(b.status));}
function emit(s,q,to,type){s.attendanceCorrections.notifications.push({id:q.id+':'+q.revision+':'+type+':'+to,to,request:q.id,type,at:new Date().toISOString(),channel:'in-app',delivery:'available',emailDelivery:'not_configured'});}
function event(s,a,q,type,detail){q.history.push({at:new Date().toISOString(),by:a.personId,type,detail});s.payrollControl.audit.push({id:'pa-'+s.payrollControl.audit.length,type,actor:a.personId,period:q.period,team:q.team,employee:q.employee,request:q.id,at:new Date().toISOString()});}
function authorise(s,a,command,x){
 if(command==='correction-submit'){assert(a.role==='employee','Employee access required.',403);record(s,a,x.period,x.record);return;}
 const q=request(s,a,x.id);
 if(command==='correction-respond'){assert(a.role==='employee'&&q.employee===a.personId,'Only the employee can respond.',403);return;}
 manager(s,a,q);
}
function submit(s,a,x,id){decorate(s);authorise(s,a,'correction-submit',x);const {p,r,t}=record(s,a,x.period,x.record);
 assert(!Object.hasOwn(x,'employee')&&!Object.hasOwn(x,'tenant')&&!Object.hasOwn(x,'role'),'Identity is taken from your signed-in account.');
 assert(typeof id==='string'&&id.length>5&&!s.attendanceCorrections.requests.some(q=>q.id===id),'A unique request identifier is required.');
 assert(!s.attendanceCorrections.requests.some(q=>q.record===r.id&&q.period===p.id&&OPEN.includes(q.status)),'There is already an open request for this attendance record.',409);
 const clockIn=E.resolveLondon(x.clockIn),clockOut=E.resolveLondon(x.clockOut);
 assert(Date.parse(clockOut)>Date.parse(clockIn)&&Date.parse(clockOut)-Date.parse(clockIn)<=26*3600000,'Provide a valid start and finish, including the next date for overnight work.');
 const source=clone(P.effective(r));const errs=P.fieldsValid({...r,correction:{...source,kind:'worked',clockIn,clockOut,breaks:[],breaksConfirmed:true,pendingSync:false,absenceMinutes:0}});
 assert(!errs.length,errs.join(' '));
 const q={id,period:p.id,record:r.id,team:t.id,employee:a.personId,status:payrollLocked(s,p,t)?'payroll_review_required':'submitted',revision:1,sourceVersion:r.sourceVersion,sourceFingerprint:fingerprint(r),original:clone({raw:r.raw,correction:r.correction||null}),requested:{clockIn,clockOut},note:note(x.note),timeZone:'Europe/London',createdAt:new Date().toISOString(),history:[],outcome:null};
 s.attendanceCorrections.requests.push(q);event(s,a,q,'attendance-correction-submitted',q.note);emit(s,q,t.owner,'request_submitted');return {id:q.id,status:q.status,revision:q.revision};
}
function review(s,a,x){const q=request(s,a,x.id),{p,t}=manager(s,a,q);checkRevision(q,x);assert(['submitted','information_required','payroll_review_required'].includes(q.status),'This request is already awaiting independent approval or has been decided.',409);assert(['question','reject'].includes(x.decision),'Choose ask for information or reject.');const text=note(x.note);q.status=x.decision==='question'?'information_required':'rejected';q.revision++;q.outcome=x.decision==='reject'?{applied:false,reason:text,by:a.personId,at:new Date().toISOString()}:null;event(s,a,q,'attendance-correction-'+x.decision,text);emit(s,q,q.employee,q.status);return {id:q.id,status:q.status,revision:q.revision};}
function respond(s,a,x){authorise(s,a,'correction-respond',x);const q=request(s,a,x.id);checkRevision(q,x);assert(q.status==='information_required','No additional information is currently requested.',409);const {p,t}=record(s,a,q.period,q.record);q.revision++;q.status=payrollLocked(s,p,t)?'payroll_review_required':'submitted';event(s,a,q,'attendance-correction-response',note(x.note));emit(s,q,t.owner,'employee_responded');return {id:q.id,status:q.status,revision:q.revision};}
function propose(s,a,x){const q=request(s,a,x.id),{p,r,t}=manager(s,a,q);checkRevision(q,x);assert(['submitted','information_required'].includes(q.status),'Only an open request can be proposed for approval.',409);assert(!payrollLocked(s,p,t),'Payroll is locked. Refer this request to payroll; no released file will be changed.',409);assert(q.sourceFingerprint===fingerprint(r),'The source attendance record changed. Reconcile the request against the latest evidence before proceeding.',409);
 const result=P.changeRecord(s,a,{attendanceRequestId:q.id,period:q.period,team:q.team,record:q.record,revision:p.reviews[t.id].revision,clockIn:x.clockIn,clockOut:x.clockOut,breakStart:x.breakStart,breakEnd:x.breakEnd,breaks:x.breaks,breaksConfirmed:x.breaksConfirmed,reason:note(x.note)});
 return {id:q.id,status:q.status,revision:q.revision};
}
function decide(s,a,x){const q=request(s,a,x.id),{p,t}=manager(s,a,q);checkRevision(q,x);assert(q.status==='awaiting_approval','This request is not awaiting approval.',409);assert(x.checked===true,'Confirm that you have reviewed the original and proposed evidence.');assert(['accept','decline'].includes(x.decision),'Accept or decline the proposal.');P.resolveIssue(s,a,{period:q.period,team:q.team,revision:p.reviews[t.id].revision,issue:q.issue,decision:x.decision,checked:true,reason:note(x.note)});return {id:q.id,status:q.status,revision:q.revision};}
function dashboard(s,a){decorate(s);assert(a.role==='employee'||MANAGERS.includes(a.role),'Attendance access required.',403);const records=[];for(const p of s.payrollControl.periods){for(const r of p.records){if(!canSee(s,a,r.employee))continue;const t=P.group(p,r.team);records.push({id:r.id,period:p.id,employee:r.employee,name:s.staff.find(e=>e.id===r.employee)?.name||r.employee,date:r.date,timeZone:'Europe/London',raw:clone(r.raw),effective:clone(P.effective(r)),workedMinutes:P.duration(r),sourceVersion:r.sourceVersion,payrollLocked:payrollLocked(s,p,t)});}}
 const requests=s.attendanceCorrections.requests.filter(q=>canSee(s,a,q.employee)).map(q=>{const {sourceFingerprint,original,...safe}=clone(q);return {...safe,history:safe.history.map(h=>({...h,actorName:s.staff.find(e=>e.id===h.by)?.name||s.org.find(e=>e.id===h.by)?.name||h.by})),name:s.staff.find(e=>e.id===q.employee)?.name||q.employee,canPropose:MANAGERS.includes(a.role)&&a.personId!==q.employee&&['submitted','information_required'].includes(q.status),canDecide:MANAGERS.includes(a.role)&&a.personId!==q.employee&&a.personId!==q.proposedBy&&q.status==='awaiting_approval'};});
 return {version:s.version,timeZone:'Europe/London',records,requests,notifications:s.attendanceCorrections.notifications.filter(n=>n.to===a.personId),source:'Existing closed-week fictional attendance records; no live tablet feed.',externalDelivery:'not_configured'};
}
function dispatch(s,a,command,x,id){decorate(s);authorise(s,a,command,x);switch(command){case 'correction-submit':return submit(s,a,x,id);case 'correction-review':return review(s,a,x);case 'correction-respond':return respond(s,a,x);case 'correction-propose':return propose(s,a,x);case 'correction-decide':return decide(s,a,x);default:assert(false,'Unknown correction action.',404);}}
const api={decorate,fingerprint,canSee,record,request,authorise,submit,review,respond,propose,decide,dashboard,dispatch};
if(typeof module!=='undefined')module.exports=api;root.WFMAttendanceCorrections=api;
})(typeof window!=='undefined'?window:globalThis);
