/* Pure, testable preview logic. Not a security boundary: all data is fictional. */
(function(root){
'use strict';
const NOW='2026-09-14T08:38:00+01:00';
const names=['Maya Bennett','Tom Wilson','Aisha Khan','Daniel Reed','Luca Rossi','Grace Evans','Jack Turner','Ben Hughes','Sofia Ahmed','Ethan Cole','Ruby Parker','Oscar Hill','Amelia Ward','Leo Green','Isla Martin','Noah James','Chloe Lewis','Oliver Clark','Freya Scott','Henry Adams','Nina Taylor','Max Brooks','Zara Ali','Theo Moore','Eva Walker','Arjun Shah','Ella King','Jacob Wood','Mia Allen','Adam Lewis','Lily Young','Hugo Grant'];
function seed(){
const org=[{id:'d1',parent:null,name:'Olivia Hart',label:'Manufacturing group',role:'Operations director'}, {id:'m1',parent:'d1',name:'Alex Morgan',label:'Tamworth factory',role:'Factory manager'}, {id:'s1',parent:'m1',name:'Sam Patel',label:'CNC machining',role:'Team leader'}, {id:'s2',parent:'m1',name:'Emma Clarke',label:'Assembly',role:'Team leader'}, {id:'s3',parent:'m1',name:'Jon Reeves',label:'Quality & packing',role:'Team leader'}, {id:'m2',parent:'d1',name:'David Ellis',label:'Leeds factory',role:'Factory manager'}, {id:'s4',parent:'m2',name:'Nina Brooks',label:'Production',role:'Team leader'}];
const staff=names.map((name,i)=>({id:'e'+i,name,manager:['s1','s2','s3','s4'][Math.floor(i/8)],site:i<24?'Tamworth':'Leeds',team:['CNC machining','Assembly','Quality & packing','Production'][Math.floor(i/8)],job:['Machine operator','Assembly technician','Quality technician','Production operator'][Math.floor(i/8)],costRate:[24,27,30,25][Math.floor(i/8)],start:'2026-09-14T06:00:00+01:00',finish:'2026-09-14T14:00:00+01:00',clockIn:'2026-09-14T05:56:00+01:00',clockOut:null,onBreak:false,sick:false,leave:false,deviceFresh:true,events:[],approvedStart:null}));
for(const [i,mins] of [[1,8],[9,12],[17,20],[25,6]])staff[i].clockIn=`2026-09-14T06:${String(mins).padStart(2,'0')}:00+01:00`;
for(const i of [4,12])staff[i].clockIn=null;staff[12].deviceFresh=false;
for(const i of [6,19])staff[i].onBreak=true;
staff[7].clockIn=null;staff[7].sick=true;staff[7].reportedAt='05:32';staff[7].reportSource='Phone call recorded by Sam Patel';
staff[15].clockIn=null;staff[15].leave=true;
staff[21].start='2026-09-13T22:00:00+01:00';staff[21].finish='2026-09-14T06:00:00+01:00';staff[21].clockIn='2026-09-13T21:56:00+01:00';staff[21].clockOut='2026-09-14T06:01:00+01:00';
staff[23].start='2026-09-14T14:00:00+01:00';staff[23].finish='2026-09-14T22:00:00+01:00';staff[23].clockIn=null;
for(const p of staff){if(p.clockIn)p.events.push({id:p.id+'-in',type:'in',at:p.clockIn,source:'Registered site tablet'});if(p.clockOut)p.events.push({id:p.id+'-out',type:'out',at:p.clockOut,source:'Registered site tablet'});}
return {org,staff,requests:[{id:'r1',employee:'e3',date:'2026-09-18',hours:7.5,status:'pending',kind:'Annual leave'},{id:'r2',employee:'e10',date:'2026-09-21',hours:7.5,status:'pending',kind:'Annual leave'},{id:'r3',employee:'e20',date:'2026-09-25',hours:7.5,status:'pending',kind:'Annual leave'}],audit:[],shifts:{}};
}
function descendants(org,id){const found=new Set();const visit=(parent)=>{if(found.has(parent))return;found.add(parent);org.filter(n=>n.parent===parent).forEach(n=>visit(n.id));};visit(id);return found;}
function scopedStaff(state,managerId,filterId){const allowed=descendants(state.org,managerId);if(filterId&&!allowed.has(filterId))return [];const scope=filterId?descendants(state.org,filterId):allowed;return state.staff.filter(p=>scope.has(p.manager));}
function lateness(p){if(!p.clockIn||p.sick||p.leave)return 0;const start=Date.parse(p.approvedStart||p.start),actual=Date.parse(p.clockIn);if(!Number.isFinite(start)||!Number.isFinite(actual))return 0;return Math.max(0,Math.round((actual-start)/60000));}
function cost(p){const minutes=lateness(p);return !minutes?0:Number.isFinite(p.costRate)?Math.round(minutes/60*p.costRate*100)/100:null;}
function status(p,now=NOW){if(p.sick)return 'sick';if(p.offDuty)return 'off';if(p.leave)return 'leave';if(p.clockOut)return 'out';if(p.clockIn)return p.onBreak?'break':'in';if(Date.parse(p.start)>Date.parse(now))return 'later';return p.deviceFresh?'missing':'sync';}
function stats(staff){const counts={off:0,in:0,break:0,out:0,missing:0,sync:0,sick:0,leave:0,later:0};staff.forEach(p=>counts[status(p)]++);return {...counts,onsite:counts.in+counts.break,rostered:staff.length,late:staff.filter(p=>lateness(p)>0).length,minutes:staff.reduce((n,p)=>n+lateness(p),0),cost:staff.some(p=>cost(p)===null)?null:Math.round(staff.reduce((n,p)=>n+cost(p),0)*100)/100};}
function canReparent(org,id,parent){return id!==parent&&!!org.find(n=>n.id===id&&n.parent!==null)&&!!org.find(n=>n.id===parent)&&!descendants(org,id).has(parent);}
function setParent(state,id,parent){if(!canReparent(state.org,id,parent))throw Error('This change would create an invalid reporting hierarchy.');state.org.find(n=>n.id===id).parent=parent;}
function decideRequest(state,id,decision,managerId){const request=state.requests.find(r=>r.id===id);if(!request||request.status!=='pending')throw Error('This request has already been decided or no longer exists.');if(!['approved','declined'].includes(decision))throw Error('Invalid decision.');if(!scopedStaff(state,managerId).some(p=>p.id===request.employee))throw Error('This request is outside your team.');if(request.employee===managerId)throw Error('Self approval is not permitted.');request.status=decision;state.audit.push({type:'leave-decision',id,decision,by:managerId,at:NOW});return request;}
const api={NOW,seed,descendants,scopedStaff,lateness,cost,status,stats,canReparent,setParent,decideRequest};if(typeof module!=='undefined')module.exports=api;root.WFM=api;
})(typeof window!=='undefined'?window:globalThis);
