/* Workforce cost domain v0.3. Deterministic planning, not a payroll/tax calculation.
 * The browser and authenticated server use this same module. Access is enforced on the server.
 * Currency amounts returned in integer pence; rates stored to four decimal places.
 */
(function (root) {
'use strict';
const E=typeof module!=='undefined'&&module.exports?require('./engine.js'):root.WFMEngine;
const HOUR=3600000, MIN=60000, NOW=E.AS_OF, SNAP='2026-09-14';
const assert=E.assert, r=E.round, copy=x=>JSON.parse(JSON.stringify(x));
const dayFmt=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/London',year:'numeric',month:'2-digit',day:'2-digit'});
const timeFmt=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/London',hour:'2-digit',hour12:false});
const localDay=t=>dayFmt.format(new Date(t));
const addDays=(d,n)=>new Date(Date.parse(d+'T12:00:00Z')+n*86400000).toISOString().slice(0,10);
const weekOf=d=>addDays(d,-((new Date(d+'T12:00:00Z').getUTCDay()+6)%7));
const monthAdd=(m,n)=>new Date(Date.UTC(Number(m.slice(0,4)),Number(m.slice(5,7))-1+n,1)).toISOString().slice(0,7);
const validDate=d=>typeof d==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(d)&&Number.isFinite(Date.parse(d+'T12:00Z'))&&new Date(d+'T12:00Z').toISOString().slice(0,10)===d;
const pence=n=>Math.round((n+Number.EPSILON)*100);
const localCache=new Map();
function london(value){if(localCache.size>10000)localCache.clear();if(!localCache.has(value))localCache.set(value,E.resolveLondon(value));return localCache.get(value);}
// Dated national-calendar snapshot transcribed from GOV.UK bank-holidays.json on 14 September 2026.
// Local/public holidays and employer closures must be separately configured. Never extrapolate unknown years.
const COMMON={2026:['01-01','04-03','04-06','05-04','05-25','08-31','12-25','12-28'],2027:['01-01','03-26','03-29','05-03','05-31','08-30','12-27','12-28']};
const SCOT={2026:['01-01','01-02','04-03','05-04','05-25','06-15','08-03','11-30','12-25','12-28'],2027:['01-01','01-04','03-26','05-03','05-31','08-02','11-30','12-27','12-28']};
function bankHoliday(date,region){assert(validDate(date),'Invalid bank-holiday date.');const year=+date.slice(0,4);assert(['england-and-wales','scotland','northern-ireland'].includes(region),'No supported bank-holiday calendar for this region.');assert(COMMON[year],'Bank-holiday calendar has no verified coverage for '+year+'.');let list=(region==='scotland'?SCOT:COMMON)[year].slice();if(region==='northern-ireland')list.push('03-17',year===2026?'07-13':'07-12');return list.includes(date.slice(5));}
function costAccess(s,a,branch){E.requireManager(s,a);assert(a.costs===true,'Employment-cost permission is required.',403);return E.allowedPeople(s,a,branch);}
function payrollAccess(s,a){costAccess(s,a);assert(a.role==='director','Payroll imports and pay-policy changes require payroll-admin (director in this build).',403);}
function rateAt(s,id,d){return (s.costing.rates[id]||[]).filter(x=>x.effectiveFrom<=d).sort((a,b)=>b.effectiveFrom.localeCompare(a.effectiveFrom))[0]||null;}
function policyAt(s,id,d){const staff=s.staff.find(p=>p.id===id);const key=s.costing.employeePolicies[id]||staff?.site;const base=(s.costing.policies[key]||[]).filter(x=>x.effectiveFrom<=d).sort((a,b)=>b.effectiveFrom.localeCompare(a.effectiveFrom))[0]||null;return root.WFMWorkRules&&s.workRules?root.WFMWorkRules.contractPolicy(s,id,d,base):base;}
function validatePolicy(p){
 assert(p&&validDate(p.effectiveFrom),'Pay policy needs an effective date.');
 assert(['highest','additive'].includes(p.stacking),'Premium stacking must be highest or additive.');
 for(const key of ['weeklyTiers','dailyTiers']){assert(Array.isArray(p[key])&&p[key].length<=8,'Invalid overtime tiers.');let prev=-1,prevMult=1;for(const t of p[key]){assert(Number.isFinite(t.afterHours)&&t.afterHours>=0&&t.afterHours>prev&&t.afterHours<=168,'Tier thresholds must be ascending hours.');assert(Number.isFinite(t.multiplier)&&t.multiplier>=prevMult&&t.multiplier>=1&&t.multiplier<=5,'Multipliers must be ascending, from 1 to 5.');prev=t.afterHours;prevMult=t.multiplier;}}
 for(const key of ['bankHolidayMultiplier','weekendMultiplier','nightMultiplier'])assert(Number.isFinite(p[key])&&p[key]>=1&&p[key]<=5,'Invalid '+key+'.');
 assert(['england-and-wales','scotland','northern-ireland'].includes(p.region),'Unsupported bank-holiday region.');
 assert(Number.isFinite(p.warningPercent)&&p.warningPercent>=50&&p.warningPercent<=100,'Warning must be 50–100%.');return p;
}
function sumRows(rows){const keys=['basePence','overtimePremiumPence','otherPremiumPence','oncostPence','grossPence','totalPence','overtimeGrossPence'];const out=Object.fromEntries(keys.map(k=>[k,0]));out.hours=0;out.overtimeHours=0;out.premiumHours=0;for(const row of rows){for(const key of keys)out[key]+=row[key];out.hours+=row.hours;out.overtimeHours+=row.overtimeHours;out.premiumHours+=row.premiumHours;}for(const key of ['hours','overtimeHours','premiumHours'])out[key]=r(out[key],4);return out;}
// Legacy rosters used different IDs from their cost estimates. Match an explicit ID
// first, otherwise require exactly one employee/interval match; never guess by date.
function sourceLedgerRow(rows,sh){
 const exact=rows.filter(x=>x.id===sh.id);
 assert(exact.length<=1,'Duplicate cost source requires reconciliation.',409);
 if(exact.length){assert(exact[0].employee===sh.employee,'Cost source employee changed; reconcile before editing.',409);return exact[0];}
 if(sh.publicationId)return null; // Modern publications already have a stable shared identity.
 const linked=rows.filter(x=>x.sourceShiftId===sh.id&&x.employee===sh.employee);
 assert(linked.length<=1,'Duplicate linked cost source requires reconciliation.',409);
 if(linked.length)return linked[0];
 // An incoming swap/publication at the same time is not an old retired duty.
 // Only unbound legacy rows may use the employee/interval fallback.
 const matches=rows.filter(x=>!x.sourceShiftId&&!x.publicationId&&x.employee===sh.employee&&E.stamp(x.start)===E.stamp(sh.start)&&E.stamp(x.end)===E.stamp(sh.end));
 assert(matches.length<=1,'Ambiguous legacy cost source requires reconciliation.',409);
 return matches[0]||null;
}
function mergeLedger(s,id){
 const rows=s.costing.ledger.filter(x=>x.employee===id),map=new Map();
 for(const row of rows){assert(!map.has(row.id),'Duplicate cost-ledger shift: '+row.id,409);map.set(row.id,{...row});}
 // Accepted cover assignments supersede earlier estimates with the same source ID.
 for(const sh of s.assignments.filter(x=>x.employee===id&&x.cover)){
  if(map.get(sh.id)?.kind==='actual')continue;
  map.set(sh.id,{...sh,kind:'planned',breaks:sh.breakMinutes?[{start:sh.breakStart,end:new Date(E.stamp(sh.breakStart)+sh.breakMinutes*MIN).toISOString(),paid:false}]:[]});
 }
 // A pure projection also repairs persisted 0.6.10 publications whose costing row
 // was never written. Drafts never enter this view. Original evidence stays intact.
 const roster=s.workRules?.roster||[],history=s.schedulePublication?.publications||[];
 const retired=new Set(history.map(p=>p.action==='amend'?p.sourceShiftId:p.action==='cancel'?p.publishedShiftId:null).filter(Boolean));
 for(const sourceId of retired){
  const sh=roster.find(x=>x.id===sourceId);assert(sh,'Publication cost source is missing; reconcile the schedule.',409);
  if(sh.employee!==id)continue;
  const row=sourceLedgerRow([...map.values()],sh);
  if(row){assert(row.kind!=='actual','Published schedule conflicts with actual cost evidence; reconcile before costing.',409);map.delete(row.id);}
 }
 for(const sh of roster.filter(x=>x.employee===id&&x.published&&x.publicationId&&!x.cancelled)){
  assert(history.some(p=>p.id===sh.publicationId&&p.publishedShiftId===sh.id),'Published cost commitment has no audit source.',409);
  const existing=map.get(sh.id);
  if(existing?.kind==='actual')continue; // Approved actual evidence supersedes its plan.
  map.set(sh.id,{...copy(sh),kind:'planned'});
 }
 return [...map.values()].filter(x=>!x.cancelled).sort((a,b)=>E.stamp(a.start)-E.stamp(b.start));
}
function priceShifts(s,id,input){
 if(root.WFMWorkRules&&s.workRules&&input.length&&input.every(x=>root.WFMWorkRules.contractAt(s,id,localDay(x.start))))return root.WFMWorkRules.priceSeries(s,id,input);
 const rows=[],issues=[],daily=new Map(),weekly=new Map(),ids=new Set();let lastEnd=-Infinity;
 const shifts=input.filter(x=>!x.cancelled).slice().sort((a,b)=>E.stamp(a.start)-E.stamp(b.start));
 for(const sh of shifts){
  assert(!ids.has(sh.id),'Duplicate cost-ledger shift: '+sh.id);ids.add(sh.id);
  const start=E.stamp(sh.start),end=E.stamp(sh.end);assert(end>start&&end-start<=26*HOUR,'Shift must be positive and no longer than 26 elapsed hours.');
  assert(start>=lastEnd,'Overlapping shifts require reconciliation before costing.');lastEnd=end;
  const breaks=(sh.breaks||[]).slice().sort((a,b)=>E.stamp(a.start)-E.stamp(b.start));let lastBreak=start;
  for(const b of breaks){const x=E.stamp(b.start),y=E.stamp(b.end);assert(x>=start&&y<=end&&y>x&&x>=lastBreak,'Invalid/overlapping break interval.');lastBreak=y;}
  // Missing break timestamps are not guessed for a pay-boundary calculation.
  if(sh.breakMinutes&&!breaks.length){issues.push({shift:sh.id,reason:'Unpaid break location is unknown.'});continue;}
  let cursor=start;
  while(cursor<end){
   const d=localDay(cursor),wk=weekOf(d),rate=rateAt(s,id,d),policy=policyAt(s,id,d);
   if(!rate||!policy){issues.push({shift:sh.id,date:d,reason:!rate?'No effective pay rate.':'No effective pay policy.'});break;}
   if(rate.currency!=='GBP'||rate.basis!=='hourly'){issues.push({shift:sh.id,date:d,reason:'Only GBP hourly employee costing is supported; salary/agency needs a separate model.'});break;}
   validatePolicy(policy);
   let holiday;try{holiday=bankHoliday(d,policy.region);}catch(err){issues.push({shift:sh.id,date:d,reason:err.message});break;}
   const midnight=E.stamp(london(addDays(d,1)+'T00:00'));
   const hour=+timeFmt.format(new Date(cursor));
   const boundaries=[end,midnight];
   for(const b of breaks){const a=E.stamp(b.start),z=E.stamp(b.end);if(a>cursor)boundaries.push(a);if(z>cursor)boundaries.push(z);}
   // Cost night windows (23:00–06:00); compliance holds for night work remain separate.
   for(const h of ['06:00','23:00']){const t=E.stamp(london(d+'T'+h));if(t>cursor)boundaries.push(t);}
   const unpaid=breaks.some(b=>!b.paid&&E.stamp(b.start)<=cursor&&E.stamp(b.end)>cursor);
   const w=weekly.get(wk)||0,dd=daily.get(d)||0;
   if(!unpaid){for(const t of policy.weeklyTiers)if(t.afterHours>w+1e-8)boundaries.push(cursor+(t.afterHours-w)*HOUR);for(const t of policy.dailyTiers)if(t.afterHours>dd+1e-8)boundaries.push(cursor+(t.afterHours-dd)*HOUR);}
   const to=Math.min(...boundaries.filter(t=>t>cursor+0.001));const hours=(to-cursor)/HOUR;
   if(!unpaid){
    const wm=policy.weeklyTiers.filter(t=>w>=t.afterHours-1e-8).at(-1)?.multiplier||1;
    const dm=policy.dailyTiers.filter(t=>dd>=t.afterHours-1e-8).at(-1)?.multiplier||1;
    const ot=Math.max(wm,dm),wd=new Date(d+'T12:00Z').getUTCDay();
    const special=Math.max(holiday?policy.bankHolidayMultiplier:1,[0,6].includes(wd)?policy.weekendMultiplier:1,(hour>=23||hour<6)?policy.nightMultiplier:1);
    const mult=policy.stacking==='highest'?Math.max(ot,special):ot+special-1;
    const base=pence(hours*rate.hourlyRate),gross=pence(hours*rate.hourlyRate*mult),otPremium=Math.min(gross-base,pence(hours*rate.hourlyRate*(ot-1)));
    // Attribute the non-overtime remainder to other premiums: sums always reconcile, no double counting.
    const other=gross-base-otPremium,oncost=pence((gross/100)*rate.oncostPercent/100+hours*(rate.oncostHourly||0));
    rows.push({shift:sh.id,kind:sh.kind||'planned',date:d,week:wk,start:new Date(cursor).toISOString(),end:new Date(to).toISOString(),hours:r(hours,8),basePence:base,grossPence:gross,overtimePremiumPence:otPremium,otherPremiumPence:other,oncostPence:oncost,totalPence:gross+oncost,overtimeHours:ot>1?hours:0,premiumHours:mult>1?hours:0,overtimeGrossPence:ot>1?gross:0,multiplier:mult,otMultiplier:ot,holiday,rate:rate.hourlyRate,rateEffectiveFrom:rate.effectiveFrom,policyVersion:policy.version});
    weekly.set(wk,w+hours);daily.set(d,dd+hours);
   }
   cursor=to;
  }
 }
 return {status:issues.length?'review':'priced',currency:'GBP',rows,issues,...sumRows(rows),complete:issues.length===0};
}
function costWindow(s,id,week,extra){
 const end=addDays(week,7);let shifts=mergeLedger(s,id).filter(x=>localDay(x.end)>=week&&localDay(x.start)<end);
 if(extra)shifts.push({...extra,id:'proposal-'+id,employee:id,kind:'proposed',breaks:extra.breakMinutes?[{start:extra.breakStart,end:new Date(E.stamp(extra.breakStart)+extra.breakMinutes*MIN).toISOString(),paid:false}]:[]});
 const bill=priceShifts(s,id,shifts);return {...bill,...sumRows(bill.rows.filter(x=>x.date>=week&&x.date<end))};
}
function quote(s,id,gap){
 const week=weekOf(localDay(gap.start));assert(weekOf(localDay(E.stamp(gap.end)-1))===week,'Cross-pay-week cover needs a separate reviewed quote.');
 const evidence=s.costing.weekEvidence[id];
 assert(evidence?.complete===true&&evidence.week===week,'Complete pay-week hours and commitments are required for this quote.');
 const before=costWindow(s,id,week),after=costWindow(s,id,week,gap);
 assert(before.complete&&after.complete,'Cost information is incomplete; review rates, breaks and calendar.');
 const fields=['basePence','grossPence','overtimePremiumPence','otherPremiumPence','oncostPence','totalPence','overtimeHours'];
 const incremental=Object.fromEntries(fields.map(k=>[k,r(after[k]-before[k],4)]));
 return {week,beforeHours:before.hours,afterHours:after.hours,incremental,rate:rateAt(s,id,localDay(gap.start))?.hourlyRate,premiumRequired:incremental.overtimePremiumPence+incremental.otherPremiumPence>0,method:'Reprices the full pay week, including later planned hours affected by this cover.',policyVersion:policyAt(s,id,localDay(gap.start)).version};
}
function alternatives(s,a,gapId){
 costAccess(s,a);const g=s.gaps.find(x=>x.id===gapId);assert(g,'Gap not found.',404);E.requireManager(s,a,g.employee);
 // Existing skills, availability, rest and working-time checks run BEFORE any cost ranking.
 const scheduled={...s,assignments:[...s.assignments,...s.costing.ledger.filter(x=>!x.cancelled)]};
 const list=E.candidates(scheduled,a,gapId).map(c=>{let q=null,issue=null;try{q=quote(s,c.employee,g);}catch(e){issue=e.message;}return {...c,quote:q,costIssue:issue,costEligible:c.status==='prechecks_clear'&&!!q};});
 list.sort((a,b)=>Number(b.costEligible)-Number(a.costEligible)||(a.costEligible&&b.costEligible?a.quote.incremental.totalPence-b.quote.incremental.totalPence:0)||(a.offersLast30Days||0)-(b.offersLast30Days||0)||a.name.localeCompare(b.name));
 const best=list.find(c=>c.costEligible);
 return {gap:g.id,bestEmployee:best?.employee||null,minimumPence:best?.quote.incremental.totalPence??null,candidates:list.map(c=>({...c,savingVersusBestPence:c.costEligible?Math.max(0,c.quote.incremental.totalPence-(best?.quote.incremental.totalPence||0)):null})),basis:'Additional estimated employer cost; unqualified, unavailable and noncompliant candidates are never cost winners.'};
}
function coverGuard(s,a,gapId,employee,approval,existing){
 const actor={...a,costs:true}; // Internal only: used to enforce policy even when requester cannot see salary.
 const analysis=alternatives(s,actor,gapId),c=analysis.candidates.find(x=>x.employee===employee);
 assert(c?.costEligible,'Cover needs clear scheduling checks and complete cost evidence.',409);
 const q=c.quote,needs=q.premiumRequired||c.savingVersusBestPence>1;let reused=false;
 if(needs){
  assert(a.costs,'A cost-authorised manager must approve this premium or higher-cost choice.',403);
  const goodOld=existing&&existing.ceilingPence>=q.incremental.totalPence&&existing.policyVersion===q.policyVersion;reused=!!goodOld;
  if(!goodOld){assert(approval?.approved===true&&typeof approval.reason==='string'&&approval.reason.trim().length>=12&&approval.reason.length<=300,'Review the alternatives and provide a reason to approve this higher-cost cover.',409);
   assert(a.role==='director'||q.incremental.overtimePremiumPence+q.incremental.otherPremiumPence<=10000,'Premium above £100 needs director approval in this sample policy.',403);}
 }
 return {required:needs,approvedBy:needs?(reused?existing.approvedBy:a.personId):null,reason:needs?(approval?.reason||existing?.reason):'Lowest-cost eligible choice without a premium.',ceilingPence:q.incremental.totalPence,policyVersion:q.policyVersion,quote:copy(q),comparisonMinimumPence:analysis.minimumPence};
}
function dashboard(s,a,branch,week='2026-09-14'){
 assert(validDate(week)&&weekOf(week)===week,'Choose a Monday pay-week start.');const staff=costAccess(s,a,branch),results=[],allSegments=[];
 for(const p of staff){let bill;try{bill=costWindow(s,p.id,week);}catch(e){bill={complete:false,issues:[{reason:e.message}],rows:[]};}const policy=policyAt(s,p.id,week),threshold=policy?.weeklyTiers[0]?.afterHours||null;const evidence=s.costing.weekEvidence[p.id];const complete=bill.complete&&evidence?.complete&&evidence.week===week;
  if(complete)allSegments.push(...bill.rows);const vals=sumRows(bill.rows||[]);results.push({employee:p.id,name:p.name,team:p.team,site:p.site,payrollId:p.payrollId,rate:rateAt(s,p.id,week)?.hourlyRate??null,threshold,headroom:threshold===null?null:r(Math.max(0,threshold-vals.hours)),status:!complete?'review':vals.premiumHours>0?'premium':threshold&&vals.hours>=threshold*(policy.warningPercent/100)?'approaching':'within',complete:!!complete,issues:bill.issues||[],...vals,actual:sumRows((bill.rows||[]).filter(x=>x.kind==='actual')),committed:sumRows((bill.rows||[]).filter(x=>x.kind!=='actual'))});
 }
 const priced=results.filter(x=>x.complete),totals=sumRows(priced),reviewCount=results.length-priced.length;
 const series=Array.from({length:7},(_,i)=>{const date=addDays(week,i);return {date,...sumRows(allSegments.filter(x=>x.date===date))};});
 const budget=s.costing.budgets[branch||a.personId]??null;
 return {week,end:addDays(week,6),currency:'GBP',scope:branch||a.personId,version:s.version,employees:results.sort((a,b)=>b.overtimePremiumPence-a.overtimePremiumPence),totals,reviewCount,totalIsComplete:reviewCount===0,actual:sumRows(priced.map(x=>x.actual)),committed:sumRows(priced.map(x=>x.committed)),budgetPence:budget,variancePence:reviewCount||budget===null?null:totals.totalPence-budget,series,alerts:results.filter(p=>p.status!=='within').map(p=>({employee:p.employee,name:p.name,status:p.status,text:p.status==='review'?'Cost evidence incomplete.':p.status==='premium'?p.overtimeHours+' overtime hours / £'+((p.overtimePremiumPence+p.otherPremiumPence)/100).toFixed(2)+' extra premiums forecast.':p.headroom+' ordinary-rate hours remain before weekly premium.'})),provenance:'Synthetic approved/committed hours for the demo pay week. Clocked-in time is not automatically payroll-approved. Employer on-costs are planning assumptions, not statutory tax calculations.'};
}
function parseCSV(text,delimiter){
 assert(typeof text==='string'&&text.length<=1000000,'CSV must be no more than 1 MB.',413);text=text.replace(/^\uFEFF/,'');assert(!text.includes('\0'),'CSV contains invalid NUL bytes.');
 if(!delimiter){const first=text.split(/\r?\n/)[0];delimiter=[';',',','\t'].map(d=>[d,first.split(d).length]).sort((a,b)=>b[1]-a[1])[0][0];}assert([',',';','\t'].includes(delimiter),'Unsupported delimiter.');
 let row=[],rows=[],cell='',quoted=false,closed=false;
 function finishCell(){assert(cell.length<=10000,'CSV cell is too long.');row.push(cell);cell='';closed=false;}
 function finishRow(){finishCell();if(row.some(c=>c.trim()!==''))rows.push(row);row=[];assert(rows.length<=1001,'Maximum 1,000 employee rows per import.');}
 for(let i=0;i<text.length;i++){const ch=text[i];if(quoted){if(ch==='"'){if(text[i+1]==='"'){cell+='"';i++;}else{quoted=false;closed=true;}}else cell+=ch;}else if(ch==='"'){assert(cell===''&&!closed,'Unexpected quote in unquoted CSV field.');quoted=true;}else if(ch===delimiter)finishCell();else if(ch==='\n'||ch==='\r'){if(ch==='\r'&&text[i+1]==='\n')i++;finishRow();}else{assert(!closed||/\s/.test(ch),'Characters after closing CSV quote.');cell+=ch;}}
 assert(!quoted,'CSV has an unclosed quoted field.');if(cell||row.length)finishRow();assert(rows.length>=2,'CSV requires a header and at least one employee row.');const headers=rows.shift().map(x=>x.trim());assert(headers.length<=60&&headers.every(Boolean),'CSV headers must be named (maximum 60 columns).');assert(new Set(headers.map(x=>x.toLowerCase())).size===headers.length,'Duplicate CSV headers.');assert(rows.every(x=>x.length===headers.length),'CSV row has a different number of columns to its header.');return {headers,rows,delimiter};
}
function suggestMapping(headers){const aliases={employee_id:['employee_id','payroll_id','employee number','employee no','employee code','payroll number','staff id'],hourly_rate:['hourly_rate','hourly rate','basic rate','basic hourly rate','rate per hour'],ordinary_pay:['ordinary_pay','ordinary pay','basic pay','basic earnings'],ordinary_hours:['ordinary_hours','ordinary hours','basic hours'],effective_from:['effective_from','effective date','effective from'],currency:['currency'],oncost_percent:['oncost_percent','employer oncost percent'],oncost_hourly:['oncost_hourly']};return Object.fromEntries(Object.entries(aliases).map(([key,names])=>[key,headers.find(x=>names.includes(x.toLowerCase().trim()))||'']));}
function strictNumber(value,name){const t=String(value).trim();assert(/^(?:0|[1-9]\d*)(?:\.\d{1,4})?$/.test(t),name+' must be a non-negative decimal using a dot (no formulas, symbols or thousands separators).');const n=Number(t);assert(Number.isFinite(n),name+' is invalid.');return n;}
function importPreview(s,a,text,options={}){
 payrollAccess(s,a);const parsed=parseCSV(text,options.delimiter||undefined),map=options.mapping||suggestMapping(parsed.headers),mode=options.mode||'explicit';assert(['explicit','ordinary'].includes(mode),'Use explicit rate or verified ordinary earnings/hours.');
 const required=mode==='explicit'?['employee_id','hourly_rate','effective_from']:['employee_id','ordinary_pay','ordinary_hours','effective_from'];for(const key of required)assert(map[key]&&parsed.headers.includes(map[key]),'Map the '+key+' column.');
 const selected=Object.values(map).filter(Boolean);assert(new Set(selected).size===selected.length,'A CSV column cannot serve two mapped purposes.');for(const h of selected)assert(parsed.headers.includes(h),'Mapped CSV header does not exist.');
 if(mode==='ordinary'){assert(options.ordinaryConfirmed===true,'Confirm that ordinary earnings exclude overtime, bonuses, deductions and holiday adjustments.');assert(!/gross|net|total|salary/i.test(map.ordinary_pay),'Gross pay, net pay, total pay and salary cannot be inferred as basic hourly pay.');}
 const valid=[],errors=[],warnings=[],seen=new Set(),allowed=new Set(E.allowedPeople(s,a).map(x=>x.id));
 parsed.rows.forEach((cells,index)=>{const line=index+2;const get=key=>map[key]?cells[parsed.headers.indexOf(map[key])].trim():'';try{
  const employeeId=get('employee_id');assert(/^[A-Za-z0-9][A-Za-z0-9_.-]{0,39}$/.test(employeeId),'Employee ID is invalid.');
  const ps=s.staff.filter(x=>x.payrollId===employeeId&&allowed.has(x.id));assert(ps.length===1,'Unknown or ambiguous employee ID; no employee was created.');const p=ps[0],effectiveFrom=get('effective_from');assert(validDate(effectiveFrom)&&effectiveFrom>='2020-01-01'&&effectiveFrom<='2035-12-31','Effective date must be an ISO YYYY-MM-DD date.');
  const key=p.id+':'+effectiveFrom;assert(!seen.has(key),'Duplicate employee/effective-date row.');seen.add(key);
  let hourlyRate;if(mode==='explicit')hourlyRate=strictNumber(get('hourly_rate'),'Hourly rate');else{const pay=strictNumber(get('ordinary_pay'),'Ordinary earnings'),hours=strictNumber(get('ordinary_hours'),'Ordinary hours');assert(hours>0&&hours<=744,'Ordinary hours must be positive, no more than 744 in a period.');hourlyRate=r(pay/hours,4);}
  assert(hourlyRate>0&&hourlyRate<=5000,'Hourly rate must be positive and no more than 5,000.');const currency=get('currency')||options.currency||'GBP';assert(currency==='GBP','This release only supports GBP; no currency conversion is inferred.');
  const old=rateAt(s,p.id,effectiveFrom),existing=s.costing.rates[p.id]?.find(x=>x.effectiveFrom===effectiveFrom);const oncostPercent=get('oncost_percent')!==''?strictNumber(get('oncost_percent'),'On-cost percentage'):(old?.oncostPercent||0),oncostHourly=get('oncost_hourly')!==''?strictNumber(get('oncost_hourly'),'Hourly on-cost'):(old?.oncostHourly||0);assert(oncostPercent<=100&&oncostHourly<=500,'Unreasonable employer-cost assumption.');
  assert(!existing||(existing.hourlyRate===hourlyRate&&existing.oncostPercent===oncostPercent&&existing.oncostHourly===oncostHourly),'A different rate already exists on this effective date; use a separately reviewed correction.');
  if(old&&Math.abs(hourlyRate/old.hourlyRate-1)>.25)warnings.push({line,employee:p.id,message:'Rate changes by more than 25%; verify the source.'});
  if(effectiveFrom<SNAP)warnings.push({line,employee:p.id,message:'Backdated rate affects retrospective estimates; payroll reconciliation is separate.'});
  if(!get('oncost_percent'))warnings.push({line,employee:p.id,message:'Employer on-cost is a carried-forward planning assumption, not extracted tax.'});
  valid.push({line,employee:p.id,payrollId:employeeId,name:p.name,effectiveFrom,hourlyRate,currency,basis:'hourly',oncostPercent,oncostHourly,previousRate:old?.hourlyRate??null,source:mode==='explicit'?'explicit payroll rate':'confirmed ordinary earnings / ordinary hours',noChange:!!existing});
 }catch(e){errors.push({line,message:e.message});}});
 return {version:s.version,mode,headers:parsed.headers,mapping:map,rowCount:parsed.rows.length,valid,errors,warnings,canApply:errors.length===0&&valid.length>0,ignoredColumns:parsed.headers.filter(h=>!selected.includes(h)),rawFileStored:false,providerUsed:false};
}
function applyImport(s,a,batchId,reviewed){
 payrollAccess(s,a);assert(reviewed===true,'Explicit review is required.');const batch=s.costing.imports.find(x=>x.id===batchId&&x.actor===a.personId);assert(batch,'Import batch not found.',404);
 if(batch.status==='applied')return {id:batch.id,status:'already_applied',rows:batch.preview.valid.length};assert(batch.status==='staged'&&batch.preview.canApply,'Fix validation errors before applying this batch.',409);assert(batch.version===s.version,'Data changed after import preview. Stage the file again before applying.',409);
 for(const item of batch.preview.valid){E.requireManager(s,a,item.employee);const rates=s.costing.rates[item.employee]??=[];assert(!rates.some(x=>x.effectiveFrom===item.effectiveFrom&&!item.noChange),'Rate changed since preview.',409);}
 for(const item of batch.preview.valid){if(!item.noChange){const {line,name,previousRate,payrollId,noChange,...rate}=item;(s.costing.rates[item.employee]??=[]).push({...rate,batch:batch.id});}}
 batch.status='applied';batch.appliedAt=NOW;E.refreshCostView(s);E.audit(s,a,'payroll-rate-import',null,batch.preview.valid.length+' reviewed rate rows; raw file not retained.');return {id:batch.id,status:'applied',rows:batch.preview.valid.length};
}
function importFingerprint(preview){return JSON.stringify(preview.valid.map(x=>({employee:x.employee,effectiveFrom:x.effectiveFrom,hourlyRate:x.hourlyRate,currency:x.currency,oncostPercent:x.oncostPercent,oncostHourly:x.oncostHourly})).sort((a,b)=>(a.employee+a.effectiveFrom).localeCompare(b.employee+b.effectiveFrom)));}
function stageImport(s,a,preview,digest,id){payrollAccess(s,a);assert(preview.canApply,'This import has validation errors.');const old=s.costing.imports.find(x=>x.digest===digest&&x.actor===a.personId&&x.status==='applied');if(old)return {id:old.id,status:'already_applied',preview:old.preview};const batch={id,digest,actor:a.personId,version:s.version+1,status:'staged',preview,createdAt:NOW};s.costing.imports.push(batch);return {id,status:'staged',preview};}
function seasonModel(rows){
 const points=rows.filter(x=>x.complete&&Number.isFinite(x.hours)&&x.hours>=0).sort((a,b)=>a.month.localeCompare(b.month));assert(points.length>=6,'At least six complete months of labour-demand history are needed.');const months=points.map(p=>p.month);assert(new Set(months).size===months.length,'Duplicate historical months must be reconciled.');
 const contiguous=points.every((p,i)=>!i||monthAdd(points[i-1].month,1)===p.month);assert(contiguous,'Historical months are missing; do not treat gaps as zero demand.');
 const n=points.length,seasonal=n>=24&&Array.from({length:12},(_,i)=>points.filter(p=>+p.month.slice(5)===i+1).length>=2).every(Boolean);
 const means=Array(12).fill(1);if(seasonal){const norm=points.map((p,i)=>{const year=points.filter(x=>x.month.slice(0,4)===p.month.slice(0,4));const mean=year.reduce((a,x)=>a+x.hours,0)/year.length;return {m:+p.month.slice(5)-1,v:mean?p.hours/mean:1};});for(let m=0;m<12;m++){const v=norm.filter(p=>p.m===m).map(x=>x.v);means[m]=v.reduce((a,b)=>a+b,0)/v.length;}const scale=means.reduce((a,b)=>a+b,0)/12;for(let m=0;m<12;m++)means[m]/=scale;}
 const recent=points.slice(-6),level=recent.reduce((a,p)=>a+p.hours/means[+p.month.slice(5)-1],0)/recent.length;
 // No automated trend extrapolation: seasonality is a baseline; business demand changes are explicit scenarios.
 return {n,seasonal,factors:means,level,predict:m=>Math.max(0,level*means[+m.slice(5)-1]),history:points};
}
function backtest(rows){if(rows.length<30)return {available:false,reason:'Need 30+ complete months for six leakage-free seasonal holdouts.'};let errors=[],naive=[];for(let i=rows.length-6;i<rows.length;i++){const model=seasonModel(rows.slice(0,i)),actual=rows[i].hours;errors.push({predicted:model.predict(rows[i].month),actual});naive.push({predicted:rows[i-12].hours,actual});}const wape=arr=>{const den=arr.reduce((n,x)=>n+x.actual,0);return den?r(arr.reduce((n,x)=>n+Math.abs(x.predicted-x.actual),0)/den*100,2):null;};return {available:true,holdouts:6,modelWape:wape(errors),seasonalNaiveWape:wape(naive),metric:'Weighted absolute percentage error on six historical months; each forecast uses only earlier records.'};}
function forecast(s,a,branch,options={}){
 const ps=costAccess(s,a,branch),ids=new Set(ps.map(p=>p.id));assert(ps.length,'No employees in this scope.');
 const demandPct=Number(options.demandPct??0),wagePct=Number(options.wagePct??0),absencePct=Number(options.absencePct??0),months=Number(options.months??12),holidayOpen=options.holidayOpen===true;
 assert(Number.isFinite(demandPct)&&demandPct>=-50&&demandPct<=100&&Number.isFinite(wagePct)&&wagePct>=-20&&wagePct<=50&&Number.isFinite(absencePct)&&absencePct>=0&&absencePct<=30&&Number.isInteger(months)&&months>=1&&months<=12,'Scenario inputs are out of range.');
 // These are explicit labour-demand/planning records, NOT an inference from lateness or sickness history.
 const hist=s.costing.demandHistory.filter(x=>ids.has(x.employee)&&x.month<'2026-09');const grouped=new Map();for(const x of hist){if(!grouped.has(x.month))grouped.set(x.month,{month:x.month,hours:0,count:0,complete:true});const t=grouped.get(x.month);t.hours+=x.hours;t.count++;t.complete=t.complete&&x.complete;}
 const history=[...grouped.values()].map(x=>({...x,hours:r(x.hours),complete:x.complete&&x.count===ps.length})).sort((a,b)=>a.month.localeCompare(b.month));const model=seasonModel(history),validation=backtest(model.history),out=[];
 for(let i=0;i<months;i++){
  const month=monthAdd('2026-10',i),end=monthAdd(month,1)+'-01',days=[];for(let d=month+'-01';d<end;d=addDays(d,1))days.push(d);
  const target=model.predict(month)*(1+demandPct/100);let cost=0,base=0,ot=0,other=0,on=0,capacity=0,holidayHours=0,missing=[],bh=new Set(),rateWeighted=0,rateHours=0;
  for(const p of ps){
   const policy=policyAt(s,p.id,month+'-01'),ordinaryWeek=policy?.weeklyTiers[0]?.afterHours||40;assert(policy,'Missing forecast pay policy.');
   const dates=days.filter(d=>{const dailyPolicy=policyAt(s,p.id,d);assert(dailyPolicy,'Missing forecast pay policy.');const weekday=new Date(d+'T12:00Z').getUTCDay(),holiday=bankHoliday(d,dailyPolicy.region);if(holiday)bh.add(d);return weekday!==0&&weekday!==6&&(holidayOpen||!holiday);});
   const h=target/ps.length,cap=dates.reduce((n,d)=>n+(policyAt(s,p.id,d)?.weeklyTiers[0]?.afterHours||40)/5,0)*(1-absencePct/100);capacity+=cap;
   if(!dates.length){missing.push(p.id+': no operating days');continue;}
   const daily=h/dates.length;
   // Aggregate capacity approximation: excess demand above reduced ordinary capacity uses first OT tier.
   // Not a generated rota; skills/rest and precise pay-week cross-month scheduling need the optimiser/roster.
   const extraFraction=h?Math.max(0,h-cap)/h:0;
   for(const d of dates){const policy=policyAt(s,p.id,d);const rate=rateAt(s,p.id,d);if(!rate||rate.currency!=='GBP'||rate.basis!=='hourly'){missing.push(p.id+': unpriced rate');continue;}const wage=rate.hourlyRate*(1+wagePct/100),normalHours=daily*(1-extraFraction),extraHours=daily*extraFraction,holiday=bankHoliday(d,policy.region),spec=holiday?policy.bankHolidayMultiplier:1,otMult=policy.weeklyTiers[0]?.multiplier||1;let multOT=policy.stacking==='highest'?Math.max(spec,otMult):spec+otMult-1;const b=daily*wage,prem=extraHours*wage*(otMult-1),g=normalHours*wage*spec+extraHours*wage*multOT,oc=g*rate.oncostPercent/100+daily*rate.oncostHourly;base+=b;ot+=prem;other+=g-b-prem;on+=oc;cost+=g+oc;if(holiday)holidayHours+=daily;rateWeighted+=wage*daily;rateHours+=daily;}
  }
  // ±15% demand scenarios, not statistical confidence intervals. Fixed/floor effects are separately caveated.
  const bp=pence(base),op=pence(ot),xp=Math.max(0,pence(other)),np=pence(on),tp=bp+op+xp+np;
  out.push({month,hours:r(target),capacityHours:r(capacity),gapHours:r(Math.max(0,target-capacity)),seasonIndex:r(model.factors[+month.slice(5)-1],3),basePence:bp,overtimePremiumPence:op,otherPremiumPence:xp,oncostPence:np,totalPence:missing.length?null:tp,lowScenarioPence:missing.length?null:pence(cost*.85),highScenarioPence:missing.length?null:pence(cost*1.15),holidayHours:r(holidayHours),bankHolidayDates:[...bh],weightedRate:rateHours?r(rateWeighted/rateHours,4):null,missing:[...new Set(missing)]});
 }
 return {scope:branch||a.personId,currency:'GBP',model:'Seasonal labour-demand baseline + employee-specific rate/capacity scenario',historyMonths:model.n,seasonality:model.seasonal,history:model.history.map(x=>({month:x.month,hours:x.hours})),factors:model.factors.map((value,i)=>({month:i+1,index:r(value,3)})),validation,series:out,options:{demandPct,wagePct,absencePct,holidayOpen,months},confidenceLabel:'Planning scenarios, not confidence intervals',provenance:s.costing.historySource,limitations:['First complete forecast month is October 2026; current partial month is excluded.','No production-demand inference from attendance. All included demand history is a separate synthetic fixture.','Even allocation across selected staff; role/line capacity and availability require a real roster before commitments.','Overtime estimate uses the first weekly tier; exact multi-tier costs are provided by the shift engine, not this monthly approximation.','Reduced capacity is modelled, not the cost of sick pay or paid leave; salaried fixed costs are not included.','±15% cost sensitivity is not a calibrated prediction interval. Future rates are used by effective date; scenario wage changes are additional.','Forecast does not assign shifts, infer individual sickness, or claim legal compliance.']};
}
function updatePolicy(s,a,input){payrollAccess(s,a);assert(['Tamworth','Leeds'].includes(input.site),'Unknown site.');const p=validatePolicy(copy(input.policy));assert(p.effectiveFrom>=SNAP,'Policy editor only allows current/future changes; retrospective corrections require separate review.');const history=s.costing.policies[input.site];assert(!history.some(x=>x.effectiveFrom===p.effectiveFrom),'A policy already exists for this effective date.');assert(typeof input.reason==='string'&&input.reason.trim().length>=12,'A policy-change reason is required.');p.version='policy-'+input.site+'-'+p.effectiveFrom+'-'+s.version;history.push(p);E.audit(s,a,'pay-policy-change',null,input.site+' effective '+p.effectiveFrom+'; '+input.reason);return {id:p.version};}
function decorate(s){
 if(s.costing?.schema===3)return E.refreshCostView(s);
 // Extend the established dataset; no replacement application and no real worker information.
 for(const [id,name] of [['e40','Rowan Shaw'],['e41','Harper Evans']])if(!s.staff.some(p=>p.id===id)){const p={...copy(s.staff.find(x=>x.id==='e32')),id,name,events:[]};s.staff.push(p);s.profiles[id]=copy(s.profiles.e32);s.availability.push({...copy(s.availability.find(x=>x.employee==='e32')),id:'av-'+id,employee:id});}
 const policy={version:'contract-demo-v1',effectiveFrom:'2020-01-01',weeklyTiers:[{afterHours:40,multiplier:1.5},{afterHours:48,multiplier:2}],dailyTiers:[],bankHolidayMultiplier:2,weekendMultiplier:1,nightMultiplier:1.15,stacking:'highest',region:'england-and-wales',warningPercent:90};
 s.costing={schema:3,rates:{},employeePolicies:{},policies:{Tamworth:[copy(policy)],Leeds:[copy(policy)]},ledger:[],weekEvidence:{},imports:[],budgets:{d1:4400000,m1:3650000,m2:950000,s1:1600000,s2:900000,s3:900000,s4:950000},calendar:{source:'https://www.gov.uk/bank-holidays.json',reviewedAt:SNAP,years:[2026,2027],scheduledRefresh:false},demandHistory:[],historySource:'Synthetic monthly required-labour-hour records, September 2023–August 2026; not extracted from arrival history.'};
 for(const p of s.staff){
  p.payrollId='NS-'+String(+p.id.slice(1)+1).padStart(4,'0');const n=+p.id.slice(1),base=p.id==='e32'?20:p.id==='e40'?18.5:p.id==='e41'?22:18+(n%7)*1.2;
  s.costing.rates[p.id]=[{effectiveFrom:'2020-01-01',hourlyRate:r(base,4),currency:'GBP',basis:'hourly',oncostPercent:18,oncostHourly:0,source:'fictional approved rate'}];
  s.costing.weekEvidence[p.id]={week:'2026-09-14',complete:true,source:'fictional approved and committed pay-week hours'};
  for(let i=0;i<5;i++){
   if((p.sick||p.leave)&&i===0)continue;if(p.offDuty&&i===0)continue;
   const d=addDays('2026-09-14',i);const hours=p.id==='e40'?10:p.id==='e41'?7:p.id==='e32'?8:7.5;
   const start=london(d+'T06:00'),end=new Date(E.stamp(start)+(hours+.5)*HOUR).toISOString();
   // Existing day-one records are a plan, not accrued/approved wages at the morning snapshot.
   s.costing.ledger.push({id:'pay-'+p.id+'-'+d,employee:p.id,start,end,kind:'planned',breaks:[{start:london(d+'T10:00'),end:london(d+'T10:30'),paid:false}]});
  }
  if(n<32&&n%5===1){const d='2026-09-19';s.costing.ledger.push({id:'pay-extra-'+p.id,employee:p.id,start:london(d+'T06:00'),end:london(d+'T14:00'),kind:'planned',breaks:[{start:london(d+'T10:00'),end:london(d+'T10:30'),paid:false}]});}
  const season=[.82,.9,1,1.02,1.05,.98,.9,.78,1.16,1.24,1.31,.84];
  for(let i=0;i<36;i++){const month=monthAdd('2023-09',i),m=+month.slice(5)-1;const hours=150*season[m]*(1+i*.002)*(1+(n%5-2)*.025)*(1+Math.sin(i*1.7+n)*.018);s.costing.demandHistory.push({employee:p.id,month,hours:r(hours,2),complete:true,source:'synthetic required labour hours'});}
 }
 return E.refreshCostView(s);
}
const api={decorate,bankHoliday,localDay,weekOf,addDays,monthAdd,validDate,rateAt,policyAt,validatePolicy,priceShifts,sourceLedgerRow,mergeLedger,costWindow,quote,alternatives,coverGuard,dashboard,parseCSV,suggestMapping,importPreview,importFingerprint,stageImport,applyImport,costAccess,payrollAccess,forecast,seasonModel,backtest,updatePolicy,sumRows};
if(typeof module!=='undefined'&&module.exports)module.exports=api;root.WFMCost=api;
})(typeof window!=='undefined'?window:globalThis);
