/* Own-record projections only. Management scope never becomes Personal scope. */
(function(root){'use strict';
const load=(n,k)=>typeof module!=='undefined'?require('./'+n+'.js'):root[k],E=load('engine','WFMEngine'),P=load('payroll-control','WFMPayroll'),O=load('operations-engine','WFMOps'),R=load('work-rules','WFMWorkRules');
function identity(s,a){const worker=s.staff.find(x=>x.id===a.personId),leader=s.org.find(x=>x.id===a.personId);let site=worker?.site||null;if(!site&&leader){const ids=E.descendants(s.org,a.personId),sites=[...new Set(s.staff.filter(x=>ids.has(x.manager)).map(x=>x.site))];site=sites.length===1?sites[0]:null;}return {id:a.personId,name:worker?.name||leader?.name||a.personId,job:worker?.job||leader?.role||'Company account',manager:s.org.find(x=>x.id===(worker?.manager||leader?.parent))?.name||null,site,employee:worker?.id||null,employmentLinked:!!worker};}
function snapshot(s,a,now=Date.now()){
 O.decorate(s);const id=identity(s,a),self={...a,role:'employee',costs:false,permissions:[]};
 const reviewed=[];for(const period of s.payrollControl.periods||[])for(const r of period.records||[])if(r.employee===a.personId){const v=P.effective(r);reviewed.push({id:r.id,date:r.date,kind:v.kind,clockIn:v.clockIn||null,clockOut:v.clockOut||null,workedMinutes:P.duration(r),breaks:v.breaks||[],payrollStatus:'reviewed source; final sign-off separate'});}
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/London',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(now));
 let leave=id.employmentLinked?O.leaveRow(s,a.personId,today):null;
 if(leave&&(today<leave.opening.yearStart||today>leave.opening.yearEnd))leave={...leave,usedMinutes:null,bookedMinutes:null,pendingMinutes:null,remainingMinutes:null,availableMinutes:null,yearStatus:'needs_review',source:'A reviewed opening for the current leave year is required. Prior-year balances cannot be assumed to carry forward.'};
 const offers=(s.offers||[]).filter(x=>x.employee===a.personId).map(x=>{const g=s.gaps.find(g=>g.id===x.gap),run=s.readiness?.runs?.find(r=>r.offerId===x.id&&r.recovery),recovery=run?{workCentre:run.recovery.workCentre,status:run.recovery.status,crossSite:x.crossSiteRecovery?{homeSite:x.crossSiteRecovery.homeSite,destinationSite:x.crossSiteRecovery.destinationSite,travelMinutesBefore:x.crossSiteRecovery.travelMinutesBefore,travelMinutesAfter:x.crossSiteRecovery.travelMinutesAfter}:null,outcome:run.recovery.outcome?{coverageResult:run.recovery.outcome.coverageResult,verificationStatus:run.recovery.outcome.verificationStatus,productionEffect:run.recovery.outcome.productionEffect}:null}:null;return {id:x.id,status:x.status,expiresAt:x.expiresAt,actionable:x.status==='pending'&&Date.parse(x.expiresAt)>now,start:g?.start,end:g?.end,site:g?.site,job:recovery?.workCentre?.label||g?.job||g?.skill||'Cover shift',recovery};}).slice(-50).reverse();
 const shifts=(s.workRules.roster||[]).filter(x=>x.employee===a.personId&&!x.cancelled&&Date.parse(x.end)>now).sort((a,b)=>Date.parse(a.start)-Date.parse(b.start)).slice(0,30).map(x=>({id:x.id,start:x.start,end:x.end,site:x.site||id.site,job:x.job||id.job,breaks:x.breaks||[],status:'published'}));
 return {identity:id,reviewed:reviewed.slice(-35),reviewedTotalMinutes:id.employmentLinked?reviewed.reduce((n,r)=>n+(r.workedMinutes||0),0):null,reviewedInvalid:reviewed.filter(x=>x.workedMinutes==null&&x.kind==='worked').length,reviewedPeriod:'Legacy closed-week evidence (7–13 September 2026); separate from personal web punches.',leave,requests:(s.requests||[]).filter(r=>r.employee===a.personId).map(r=>({id:r.id,date:r.date,start:r.start,end:r.end,hours:r.hours,status:r.status,kind:r.kind||'Annual leave'})).slice(-50).reverse(),offers,shifts,notices:(s.operations.notices||[]).filter(n=>n.employee===a.personId).slice(-20),availability:(s.availability||[]).filter(x=>x.employee===a.personId).slice(-30),sourceVersion:s.version};
}
function workCommand(s,a,command,payload,now=Date.now()){
 E.assert(s.staff.some(x=>x.id===a.personId),'Link an employment record before requesting leave or accepting work.',409);
 E.assert(!('employee' in payload)&&!('tenant' in payload)&&!('personId' in payload),'The personal subject is derived from your session.',403);
 const self={...a,role:'employee',costs:false,permissions:[]};
 if(command==='leave-request')return R.requestLeave(s,self,payload);
 if(command==='availability')return E.setAvailability(s,self,payload)||{id:a.personId};
 if(command==='respond'){const o=s.offers.find(o=>o.id===payload.id&&o.employee===a.personId);E.assert(o,'Offer not found.',404);E.assert(Date.parse(o.expiresAt)>now,'This offer has expired. Ask your manager for a new offer.',409);return E.respondOffer(s,self,payload.id,payload.decision);}
 E.assert(false,'Unknown personal work action.',404);
}
const api={identity,snapshot,workCommand};if(typeof module!=='undefined')module.exports=api;root.WFMPersonalView=api;
})(typeof window!=='undefined'?window:globalThis);
