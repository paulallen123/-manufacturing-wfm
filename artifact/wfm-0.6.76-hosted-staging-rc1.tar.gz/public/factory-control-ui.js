/* 0.6.23 Factory Control Centre — structural UI evolution only.
   Existing server-side authority, payroll, eligibility and publication controls remain authoritative. */
'use strict';

const FCC={board:null,epoch:0,drawer:null};
const fccManager=()=>!isEmployee()&&['manager','director','supervisor'].includes((typeof rtActor==='function'?rtActor():me()).role||ui.role);
const fccActor=()=>typeof rtActor==='function'?rtActor():{personId:me().id,role:ui.role,costs:canCost(),permissions:[]};
const fccScope=()=>{const actor=fccActor();const allowed=WFMEngine.descendants(data.org,actor.personId);return allowed.has(ui.root)?ui.root:actor.personId;};
const fccCount=(n,singular,plural)=>`${n} ${n===1?singular:(plural||singular+'s')}`;
const fccStateLabel=s=>({gap:'Gap',review:'Review',clear:'Clear'}[s]||'Review');
const fccStateClass=s=>s==='clear'?'clear':s==='gap'?'gap':'review';

function fccWorkspaceTabs(active=ui.page){
  const tabs=[
    ['overview','Control centre'],
    ['schedule-publication','Schedule'],
    ['readiness','Readiness'],
    ['time-review','Time'],
    ...(canCost()?[['payroll-run','Payroll']]:[]),
    ['organisation','People & structure']
  ];
  return `<nav class="fcc-workspaces" aria-label="Primary workspaces">${tabs.map(([page,label])=>`<button type="button" class="fcc-workspace ${active===page?'active':''}" data-act="fcc-nav" data-page="${page}">${esc(label)}</button>`).join('')}</nav>`;
}

function fccAction(iconName,title,detail,count,page,tone='review'){
  return `<button type="button" class="fcc-action ${tone}" data-act="fcc-nav" data-page="${page}"><span class="fcc-action-icon">${icon(iconName)}</span><span class="fcc-action-copy"><b>${esc(title)}</b><small>${esc(detail)}</small></span><strong>${esc(String(count))}</strong>${icon('arrow')}</button>`;
}

function fccCentreMap(board){
  if(!board?.departments?.length)return `<div class="fcc-empty">Readiness evidence is unavailable for this scope. Open Shift readiness for the detailed source status.</div>`;
  return board.departments.map(dept=>{
    const reqs=dept.requirements||[];
    const centres=reqs.length?reqs.map(req=>{
      const status=req.worstSkillGap||req.worstHeadcountGap?'gap':dept.status==='review'?'review':'clear';
      const label=req.workCentre?.label||req.workCentre?.code||'Department requirement';
      const gap=req.worstSkillGap?`Skill gap ${req.worstSkillGap}`:req.worstHeadcountGap?`People gap ${req.worstHeadcountGap}`:'Configured coverage clear';
      return `<button type="button" class="fcc-centre ${fccStateClass(status)}" data-act="fcc-nav" data-page="readiness"><span class="fcc-centre-dot"></span><span><b>${esc(label)}</b><small>${esc(gap)}</small></span><em>${esc(fccStateLabel(status))}</em></button>`;
    }).join(''):`<button type="button" class="fcc-centre review" data-act="fcc-nav" data-page="readiness"><span class="fcc-centre-dot"></span><span><b>${esc(dept.name)}</b><small>No explicit work-centre requirement</small></span><em>Review</em></button>`;
    return `<section class="fcc-dept"><header><div><span class="eyebrow">${esc(dept.name)}</span><b>${fccCount(reqs.length,'requirement')}</b></div><span class="fcc-dept-status ${fccStateClass(dept.status)}">${esc(fccStateLabel(dept.status))}</span></header><div class="fcc-centres">${centres}</div></section>`;
  }).join('');
}

function fccDecisionLane(board,stats){
  const pendingLeave=data.requests.filter(r=>r.status==='pending'&&people().some(p=>p.id===r.employee)).length;
  const payrollTeams=(typeof RF!=='undefined'&&RF.report?.teams)?RF.report.teams.filter(t=>t.status!=='signed').length:0;
  const unresolved=(stats.missing||0)+(stats.sync||0);
  const gaps=board?.gaps?.length??board?.summary?.gaps??0;
  const late=stats.late||0;
  const actions=[];
  if(payrollTeams)actions.push(fccAction('check','Weekly review','Teams still need manager sign-off before payroll hand-off.',payrollTeams,'weekly-review','gap'));
  if(gaps)actions.push(fccAction('alert','Production coverage','A work-centre or department has a timed staffing gap.',gaps,'readiness','gap'));
  if(unresolved)actions.push(fccAction('clock','Clocking evidence','Missing or awaiting-sync evidence needs manager review.',unresolved,'time-review','review'));
  if(pendingLeave)actions.push(fccAction('health','Time-off decisions','Requests are waiting for a scoped manager decision.',pendingLeave,'leave','review'));
  if(late)actions.push(fccAction('clock','Attendance trend','Late starts are visible for factual review; no disciplinary inference.',late,'attendance','neutral'));
  if(!actions.length)actions.push(`<div class="fcc-all-clear"><span>${icon('check')}</span><div><b>No immediate manager action in this snapshot.</b><p>Keep monitoring readiness, attendance evidence and new requests.</p></div></div>`);
  return actions.slice(0,4).join('');
}

function fccPulse(board,stats){
  const departments=board?.departments||[];
  const demand=departments.reduce((n,d)=>n+Number(d.demand?.requiredHours||0),0);
  const capacity=departments.reduce((n,d)=>n+Number(d.demand?.scheduledPaidHours||0),0);
  const pct=demand>0?Math.max(0,Math.min(130,Math.round(capacity/demand*100))):null;
  return `<div class="fcc-pulse-grid">
    <div><small>Recorded on site</small><strong>${stats.onsite}</strong><span>${stats.in} working · ${stats.break} on break</span></div>
    <div><small>Unresolved clock evidence</small><strong>${(stats.missing||0)+(stats.sync||0)}</strong><span>Unknown is not treated as absence</span></div>
    <div><small>Work-centre gaps</small><strong>${board?.gaps?.length??board?.summary?.gaps??'—'}</strong><span>Qualification and allocation checks</span></div>
    <div><small>Scheduled capacity vs demand</small><strong>${pct===null?'—':pct+'%'}</strong><span>${demand?`${demand.toFixed(1)}h demand · ${capacity.toFixed(1)}h scheduled`:'Demand evidence incomplete'}</span></div>
  </div>`;
}

function fccControlCentre(board){
  const ps=people(),stats=WFM.stats(ps);
  const payrollTeams=(typeof RF!=='undefined'&&RF.report?.teams)?RF.report.teams.filter(t=>t.status!=='signed').length:0;
  const needs=(stats.missing||0)+(stats.sync||0)+(stats.sick||0)+(board?.gaps?.length||0)+data.requests.filter(r=>r.status==='pending'&&ps.some(p=>p.id===r.employee)).length+payrollTeams;
  const first=esc(me().name.split(' ')[0]);
  return `${fccWorkspaceTabs('overview')}
  <section class="fcc-hero">
    <div class="fcc-hero-copy"><span class="fcc-kicker">FACTORY CONTROL CENTRE · ${esc(scopeName())}</span><h1>Know what needs<br>your decision.</h1><p>One operational view of workforce evidence, production coverage and the next safe action. Detail stays available when you need it.</p><div class="fcc-hero-actions">${button('Open weekly schedule','fcc-nav','primary','data-page="schedule-publication"')}${button('Inspect readiness','fcc-nav','','data-page="readiness"')}</div></div>
    <div class="fcc-decision-number"><small>RIGHT NOW</small><strong>${needs}</strong><span>${needs===1?'item':'items'} needing review across this scope</span><p>Good morning, ${first}. Nothing here bypasses the underlying approval or eligibility controls.</p></div>
  </section>
  ${fccPulse(board,stats)}
  <div class="fcc-layout">
    <section class="fcc-main"><div class="fcc-section-head"><div><span class="eyebrow">DECISION LANE</span><h2>What needs attention</h2><p>Ordered around actions a manager can actually progress.</p></div><button type="button" class="fcc-text-link" data-act="fcc-nav" data-page="time-review">Open full review queue ${icon('arrow')}</button></div><div class="fcc-actions">${fccDecisionLane(board,stats)}</div></section>
    <aside class="fcc-side"><span class="eyebrow">SHIFT PULSE</span><h2>Factory status</h2><div class="fcc-side-row"><span>Working now</span><b>${stats.in}</b></div><div class="fcc-side-row"><span>Reported sick</span><b>${stats.sick}</b></div><div class="fcc-side-row"><span>Late starts</span><b>${stats.late}</b></div><div class="fcc-side-row"><span>Pending leave</span><b>${data.requests.filter(r=>r.status==='pending'&&ps.some(p=>p.id===r.employee)).length}</b></div><button type="button" class="btn" data-act="fcc-nav" data-page="attendance">Inspect attendance</button></aside>
  </div>
  <section class="fcc-map"><div class="fcc-section-head"><div><span class="eyebrow">FACTORY MAP</span><h2>Work-centre readiness</h2><p>Readiness is shown as evidence, not a safety or production clearance.</p></div><button type="button" class="btn" data-act="fcc-nav" data-page="readiness">Open decision desk</button></div><div class="fcc-dept-grid">${fccCentreMap(board)}</div></section>
  <section class="fcc-week"><div><span class="eyebrow">PLAN THE NEXT MOVE</span><h2>From signal to action</h2><p>A gap should lead directly to a controlled decision, not another dashboard.</p></div><div class="fcc-flow"><button data-act="fcc-nav" data-page="readiness"><span>1</span><b>Find the gap</b><small>Demand + skill coverage</small></button><i>→</i><button data-act="fcc-nav" data-page="readiness"><span>2</span><b>Assess options</b><small>Eligibility + donor impact</small></button><i>→</i><button data-act="fcc-nav" data-page="schedule-publication"><span>3</span><b>Confirm the rota</b><small>Consent + final checks</small></button><i>→</i><button data-act="fcc-nav" data-page="time-review"><span>4</span><b>Verify outcome</b><small>Attendance + actuals</small></button></div></section>`;
}

async function fccLoadBoard(){
  const actor=fccActor(),scope=fccScope();ui.root=scope;
  try{
    if(typeof OFFLINE!=='undefined'&&OFFLINE){if(!data.readiness&&typeof WFMReadiness?.seedFixture==='function')WFMReadiness.seedFixture(data);return WFMReadiness.board(data,actor,scope);}
    return await request('/api/readiness?'+new URLSearchParams({scope}));
  }catch(_){return null;}
}

function fccDrawerRoot(){
  let node=document.getElementById('fcc-drawer');
  if(node)return node;
  node=document.createElement('aside');node.id='fcc-drawer';node.className='fcc-drawer';node.setAttribute('aria-live','polite');node.setAttribute('aria-hidden','true');document.body.appendChild(node);return node;
}
function fccCloseDrawer(){const d=document.getElementById('fcc-drawer');if(!d)return;d.classList.remove('open');d.setAttribute('aria-hidden','true');}
function fccScheduleRecord(id){const r=typeof SCH!=='undefined'?SCH.report:null;if(!r)return null;return [...(r.published||[]),...(r.drafts||[])].find(x=>String(x.id)===String(id))||null;}
function fccOpenShift(id){
  const r=fccScheduleRecord(id);if(!r)return;
  const d=fccDrawerRoot();const employee=data.staff.find(p=>p.id===r.employee);const published=(SCH.report?.published||[]).some(x=>String(x.id)===String(id));
  const issues=r.issues||[];
  d.innerHTML=`<div class="fcc-drawer-head"><div><span class="eyebrow">${published?'PUBLISHED ASSIGNMENT':'PRIVATE DRAFT'}</span><h2>${esc(employee?.name||r.employee)}</h2><p>${esc(r.site||'')} · ${esc(r.job||'Shift')}</p></div><button type="button" class="fcc-drawer-close" data-act="fcc-drawer-close" aria-label="Close decision drawer">×</button></div><div class="fcc-drawer-time"><strong>${esc(schWhen(r.start))}</strong><span>to</span><strong>${esc(schWhen(r.end))}</strong></div><div class="fcc-drawer-state"><span>Status</span><b>${published?'Published':esc(r.status||'Draft')}</b></div>${issues.length?`<div class="fcc-drawer-warning"><b>${fccCount(issues.length,'check')} still visible</b><p>${issues.slice(0,3).map(x=>esc(x.message||x.label||x)).join(' · ')}</p></div>`:`<div class="fcc-drawer-ok">${icon('check')}<span><b>No visible draft warning in this snapshot.</b><small>Server checks still run again at publication/amendment.</small></span></div>`}<div class="fcc-drawer-actions">${published&&r.canManageDestination!==false?button('Amend published shift','fcc-shift-amend','primary',`data-id="${esc(r.id)}"`):''}${!published?button('Open draft actions','fcc-shift-draft','primary',`data-id="${esc(r.id)}"`):''}${button('View readiness','fcc-nav','',`data-page="readiness"`)}</div><details><summary>Decision evidence</summary><p>Assignment ID: ${esc(r.id)}</p><p>Destination authority, qualification, absence, overlap, rest and pay evidence remain governed by the existing publication service.</p></details>`;
  d.classList.add('open');d.setAttribute('aria-hidden','false');
}

function fccPostRender(){
  if(isEmployee())return;
  const content=document.querySelector('.content');if(!content)return;
  if(ui.page!=='overview'&&!content.querySelector('.fcc-workspaces'))content.insertAdjacentHTML('afterbegin',fccWorkspaceTabs(ui.page));
  if(ui.page==='schedule-publication'){
    content.classList.add('fcc-planner-page');
    const week=content.querySelector('.sch-week-panel');
    if(week&&!content.querySelector('.fcc-planner-intro'))week.insertAdjacentHTML('beforebegin',`<section class="fcc-planner-intro"><div><span class="eyebrow">OPERATIONAL PLANNER</span><h2>Build the week around demand, skills and actual decisions.</h2><p>Select any shift to inspect it in context. The underlying publication controls still perform the authoritative checks.</p></div><div class="fcc-planner-keys"><span><i class="published"></i>Published</span><span><i class="draft"></i>Draft</span><span><i class="issue"></i>Needs checks</span></div></section>`);
  }
}

const fccOldRender=render;
render=async function(){
  if(isEmployee()||ui.page!=='overview'){
    const result=await fccOldRender();fccPostRender();return result;
  }
  if(typeof F!=='undefined'&&!F.ready)return fccOldRender();
  const epoch=++FCC.epoch;if(typeof payrollReport==='function'){try{await payrollReport();}catch(_){}}
  FCC.board=await fccLoadBoard();if(epoch!==FCC.epoch||ui.page!=='overview'||isEmployee())return;
  document.getElementById('root').innerHTML=shell(fccControlCentre(FCC.board));
  document.title='Workforce · Factory Control Centre';saveOffline?.();fccPostRender();
};

document.addEventListener('click',e=>{
  const b=e.target.closest('[data-act]');if(!b)return;
  if(b.dataset.act==='fcc-nav'){e.preventDefault();fccCloseDrawer();nav(b.dataset.page);return;}
  if(b.dataset.act==='fcc-drawer-close'){e.preventDefault();fccCloseDrawer();return;}
  if(b.dataset.act==='fcc-shift-amend'){e.preventDefault();fccCloseDrawer();schAmend(b.dataset.id);return;}
  if(b.dataset.act==='fcc-shift-draft'){e.preventDefault();fccCloseDrawer();const card=[...document.querySelectorAll('.sch-card')].find(x=>x.textContent.includes(b.dataset.id));card?.scrollIntoView({behavior:'smooth',block:'center'});return;}
},true);

document.addEventListener('click',e=>{
  const chip=e.target.closest('.sch-shift-chip');if(!chip||ui.page!=='schedule-publication'||isEmployee())return;
  e.preventDefault();e.stopImmediatePropagation();fccOpenShift(chip.dataset.id);
},true);

document.addEventListener('keydown',e=>{if(e.key==='Escape')fccCloseDrawer();});
window.factoryControlPreview={state:()=>FCC,openShift:fccOpenShift,closeDrawer:fccCloseDrawer};
// The standalone review bundle may finish its initial render before this final structural layer loads.
// Re-render once after load so the latest manager surface is visible without changing any saved state.
setTimeout(()=>{try{if(typeof F!=='undefined'&&F.ready&&!isEmployee()&&ui.page==='overview')render();}catch(_){}},0);
