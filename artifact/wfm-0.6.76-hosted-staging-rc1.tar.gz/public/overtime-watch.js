/* Explainable overtime screening. An alert is a question for a reviewer, never a finding of misconduct.
 * Pure statistics are separate from the existing authoritative contract/pay engine and source adapter.
 * NIST modified Z-score is a candidate-outlier heuristic, not a probability or legal test. */
(function(root){'use strict';
const E=typeof module!=='undefined'&&module.exports?require('./engine'):root.WFMEngine;
const C=typeof module!=='undefined'&&module.exports?require('./cost-engine'):root.WFMCost;
const R=typeof module!=='undefined'&&module.exports?require('./work-rules'):root.WFMWorkRules;
const P=typeof module!=='undefined'&&module.exports?require('./payroll-control'):root.WFMPayroll;
const assert=E.assert,DAY=86400000,MIN=60000,clone=x=>JSON.parse(JSON.stringify(x));
const VERSION='ot-watch-1';
function fingerprint(value){const strip=x=>Array.isArray(x)?x.map(strip):x&&typeof x==='object'?Object.fromEntries(Object.entries(x).filter(([k])=>!k.endsWith('Pence')).map(([k,v])=>[k,strip(v)])):x;const text=P.canonical(strip(value));return typeof module!=='undefined'&&module.exports?require('node:crypto').createHash('sha256').update(text).digest('hex'):text;}
const DEFAULT={enabled:true,minimumHistory:6,lookbackWeeks:26,minimumExcessMinutes:120,relativeIncrease:0.5,modifiedZThreshold:3.5,lateClockMinutes:60};
function settings(value={}){const p={...DEFAULT,...value};assert(typeof p.enabled==='boolean','Enabled must be true or false.');for(const [k,lo,hi] of [['minimumHistory',4,26],['lookbackWeeks',6,104],['minimumExcessMinutes',15,1440],['lateClockMinutes',15,480]])assert(Number.isSafeInteger(p[k])&&p[k]>=lo&&p[k]<=hi,'Invalid '+k+'.');assert(p.minimumHistory<=p.lookbackWeeks,'History minimum exceeds lookback.');assert(Number.isFinite(p.relativeIncrease)&&p.relativeIncrease>=0.1&&p.relativeIncrease<=5,'Relative increase must be between 10% and 500%.');assert(Number.isFinite(p.modifiedZThreshold)&&p.modifiedZThreshold>=2&&p.modifiedZThreshold<=10,'Invalid statistical threshold.');return p;}
function median(values){if(!values.length)return null;const v=values.slice().sort((a,b)=>a-b),m=Math.floor(v.length/2);return v.length%2?v[m]:(v[m-1]+v[m])/2;}
function numeric(x){return Number.isFinite(x)&&x>=0&&x<=7*24*60;}
function material(actual,expected,p){const delta=actual-expected;return delta>=p.minimumExcessMinutes&&delta>=Math.max(expected,0)*p.relativeIncrease;}
function evaluate(current,history,config={}){
 const p=settings(config),out={algorithmVersion:VERSION,status:'within_expected',flags:[],actions:[],actualMinutes:null,expectedMinutes:null,historyMedian:null,historyMAD:null,modifiedZ:null,historyCount:0,excludedHistory:0,excessMinutes:null,confidence:'Not a probability; a configurable review heuristic.',warnings:[],automaticAction:false};
 assert(current&&typeof current.regime==='string'&&current.regime.length>0,'A comparability regime is required.');
 assert(Number.isFinite(Date.parse(current.periodStart))&&Number.isFinite(Date.parse(current.through)),'Valid period timestamps required.');
 assert(Number.isInteger(current.phase)&&current.phase>=0&&current.phase<=10080,'Comparable elapsed phase required.');
 if(!p.enabled){out.status='disabled';return out;}
 if(current.complete!==true||!numeric(current.overtimeMinutes)){out.status='data_review';out.flags.push({code:'SOURCE_REVIEW',message:current.reason||'Complete, verified attendance evidence is required. Missing data is not zero overtime.'});out.actions.push('Check missing clock-outs, pending synchronisation, breaks and source completeness.');return out;}
 out.actualMinutes=current.overtimeMinutes;
 const hasPlan=numeric(current.expectedMinutes)&&current.planComparable===true;
 out.expectedMinutes=hasPlan?current.expectedMinutes:null;
 if(!hasPlan)out.warnings.push('No verified like-for-like plan snapshot for this elapsed period. Plan variance is unavailable.');
 if(current.payrollApproved!==true)out.warnings.push('Recorded attendance, not payroll-approved time. No pay is changed by this screen.');
 const seen=new Set(),clean=[],conflicts=new Set(),byPeriod=new Map();
 for(const h of history||[]){const k=h.periodStart,shape=P.canonical(h);if(byPeriod.has(k)&&byPeriod.get(k)!==shape)conflicts.add(k);else byPeriod.set(k,shape);}
 if(conflicts.size)out.warnings.push('Conflicting historical versions excluded; reconcile the source before relying on the baseline.');
 for(const h of history||[]){const key=h.periodStart;const t=Date.parse(h.periodStart),end=Date.parse(h.periodEnd);const age=(Date.parse(current.periodStart)-t)/DAY;
  if(conflicts.has(key)||seen.has(key)){out.excludedHistory++;continue;}seen.add(key);
  if(h.complete!==true||h.reviewed!==true||!numeric(h.overtimeMinutes)||h.regime!==current.regime||h.phase!==current.phase||!Number.isFinite(t)||!Number.isFinite(end)||end>Date.parse(current.periodStart)||age<=0||age>p.lookbackWeeks*7||h.exceptional===true){out.excludedHistory++;continue;}
  clean.push(h);
 }
 clean.sort((a,b)=>Date.parse(b.periodStart)-Date.parse(a.periodStart));out.historyCount=clean.length;
 const vsPlan=hasPlan&&material(current.overtimeMinutes,current.expectedMinutes,p);
 if(vsPlan){out.flags.push({code:'ABOVE_PLAN',message:'Recorded overtime is materially higher than the verified plan for the same elapsed period.'});out.excessMinutes=current.overtimeMinutes-current.expectedMinutes;}
 if(clean.length>=p.minimumHistory){
  const med=median(clean.map(x=>x.overtimeMinutes)),mad=median(clean.map(x=>Math.abs(x.overtimeMinutes-med)));out.historyMedian=med;out.historyMAD=mad;
  const z=mad===0?null:0.6745*(current.overtimeMinutes-med)/mad;out.modifiedZ=z==null?null:Math.round(z*100)/100;
  const unusual=material(current.overtimeMinutes,med,p)&&(mad===0||z>p.modifiedZThreshold);
  if(unusual){const planned=hasPlan&&!vsPlan;out.flags.push({code:planned?'PLANNED_INCREASE':'UNUSUAL_HISTORY',message:planned?'Higher than personal history, but explained by the verified current plan. Check the business reason, not the employee.':'Higher than this person’s comparable reviewed history. Check the underlying records and operational context.'});if(out.excessMinutes==null)out.excessMinutes=Math.max(0,current.overtimeMinutes-med);}
 }else out.warnings.push('Insufficient comparable reviewed history for statistical screening ('+clean.length+'/'+p.minimumHistory+').');
 if(out.flags.some(f=>['ABOVE_PLAN','UNUSUAL_HISTORY'].includes(f.code))){out.status='review';out.actions.push('Check approved extra work, shift changes and emergency cover.','Check missed clock-out, duplicate imports and recorded breaks.','Review eligible lower-cost cover before the next shift; never remove earned pay automatically.');}
 else if(out.flags.some(f=>f.code==='PLANNED_INCREASE')){out.status='planned_increase';out.actions.push('Confirm the demand, shutdown recovery or absence-cover explanation.');}
 else if(clean.length<p.minimumHistory){out.status='insufficient_history';}
 return out;
}
function decorate(s){s.overtimeWatch??={version:1,revision:0,settings:{...DEFAULT},reviews:[]};return s;}
function authorised(s,a,id){assert(['manager','supervisor','director'].includes(a.role),'Management overtime access is required.',403);assert(E.allowedPeople(s,a).some(p=>p.id===id),'Employee not available in your reporting scope.',404);}
function regime(s,id,date){const c=R.contractAt(s,id,date),emp=s.staff.find(p=>p.id===id);if(!c)return null;return JSON.stringify({contract:c.id,revision:c.revision,type:c.type,threshold:R.threshold(c),dailyAfter:c.dailyAfter,site:emp?.site,job:emp?.job});}
function bounds(week,now){assert(C.validDate(week)&&new Date(week+'T12:00Z').getUTCDay()===1,'Choose a valid Monday.');const start=E.stamp(E.resolveLondon(week+'T00:00')),end=E.stamp(E.resolveLondon(C.addDays(week,7)+'T00:00'));assert(start<now,'The selected week has not started.');const through=Math.min(end,Math.floor(now/MIN)*MIN);const local=R.localInfo(through);const phase=through===end?10080:Math.round((Date.parse(local.date+'T00:00Z')-Date.parse(week+'T00:00Z'))/DAY)*1440+local.minute;return {start,end,through,phase};}
function clip(rows,through){return rows.filter(r=>E.stamp(r.start)<through).map(r=>({...r,end:new Date(Math.min(E.stamp(r.end),through)).toISOString(),breaks:(r.breaks||[]).filter(b=>E.stamp(b.start)<through).map(b=>({...b,end:new Date(Math.min(E.stamp(b.end),through)).toISOString()}))})).filter(r=>E.stamp(r.end)>E.stamp(r.start));}
function evidence(s,id,week,through,observedAt=through){
 const p=s.payrollControl.periods.find(p=>p.id===week),c=R.contractAt(s,id,week),base={periodStart:E.resolveLondon(week+'T00:00'),through:new Date(through).toISOString(),regime:regime(s,id,week)||'missing',complete:false,overtimeMinutes:null,expectedMinutes:null,planComparable:false,payrollApproved:false,source:p?.source||'none',sourceVersion:null};
 if(!p){base.reason='No authoritative attendance review feed exists for this week. Personal web punches remain a separate unreviewed source.';return base;}
 if(!c||c.overtimeBasis==='annual'){base.reason='A supported weekly-hours contract is required. Annualised hours need a verified annual-balance comparator.';return base;}
 const team=p.teams.find(t=>t.employees.includes(id)),rows=p.records.filter(r=>r.employee===id);if(!team?.feedComplete){base.reason='The team’s attendance feed is not marked complete.';return base;}
 const relevant=rows.filter(r=>E.stamp(E.resolveLondon(r.date+'T00:00'))<through);
 if(!relevant.length||relevant.some(r=>P.fieldsValid(r).length)){base.reason='Invalid, missing or unresolved clock/break evidence must be reviewed first.';return base;}
 // Require explicit rows for every elapsed business date; absent dates do not become zero work.
 const lastDate=R.localInfo(Math.max(through-1,E.stamp(base.periodStart))).date;
 for(let d=week;d<=lastDate;d=C.addDays(d,1)){if(!relevant.some(r=>r.date===d)){base.reason='The attendance feed has a missing day: '+d;return base;}}
 const actual=relevant.filter(r=>P.effective(r).kind==='worked').map(r=>{const v=P.effective(r);return {id:r.id,start:v.clockIn,end:v.clockOut,breaks:r.timeReviewTreatment&&root.WFMTimeReview?root.WFMTimeReview.payBreaks(r):v.breaks||[],job:s.staff.find(p=>p.id===id)?.job,kind:'recorded'};});
 if(actual.some(r=>E.stamp(r.end)>observedAt)){base.reason='This period contains open or future attendance. Complete the current interval before comparing it.';return base;}
 try{const q=R.priceSeries(s,id,clip(actual,through));if(!q.complete){base.reason=q.issues.map(x=>x.reason).join(' ');return base;}base.complete=true;base.overtimeMinutes=Math.round(q.overtimeHours*60);base.grossPence=q.grossPence;base.sourceVersion=JSON.stringify(relevant.map(r=>[r.id,r.sourceVersion,r.correction||null,r.timeReviewTreatment||null]));base.payrollApproved=P.stateOf(s,p,team)==='signed';
  // A mutable current rota is NOT a historical plan baseline. Use an explicitly retained approved snapshot only.
  const snap=p.planSnapshot?.[id];if(snap?.approved===true&&snap.complete===true&&Array.isArray(snap.assignments)&&snap.periodStart===week&&typeof snap.reference==='string'&&Number.isFinite(Date.parse(snap.approvedAt))&&Date.parse(snap.approvedAt)<=through){
   const qp=R.priceSeries(s,id,clip(snap.assignments,through));if(qp.complete){base.expectedMinutes=Math.round(qp.overtimeHours*60);base.planComparable=true;base.planReference=snap.reference;base.expectedGrossPence=qp.grossPence;}}
 }catch(e){base.complete=false;base.reason=e.message;}
 return base;
}
function report(s,a,week,now=Date.now(),signals=[],page={}){decorate(s);assert(['manager','supervisor','director'].includes(a.role),'Management overtime access is required.',403);const b=bounds(week,now),cfg=settings(s.overtimeWatch.settings),allPeople=E.allowedPeople(s,a),rows=[];const offset=page.offset||0,limit=page.limit||25;assert(Number.isSafeInteger(offset)&&offset>=0&&Number.isSafeInteger(limit)&&limit>0&&limit<=100,'Invalid report page.');const people=page.employee?allPeople.filter(p=>p.id===page.employee):allPeople.slice(offset,offset+limit);
 assert(people.length<=10000,'Scope exceeds the development analysis limit.');
 for(const person of people){const current={...evidence(s,person.id,week,b.through,now),phase:b.phase};const history=[];
  for(const period of s.payrollControl.periods){if(period.id>=week)continue;const hb=bounds(period.id,now),through=b.phase===10080?hb.end:E.stamp(E.resolveLondon(C.addDays(period.id,Math.floor(b.phase/1440))+'T'+String(Math.floor(b.phase%1440/60)).padStart(2,'0')+':'+String(b.phase%60).padStart(2,'0'))),h=evidence(s,person.id,period.id,through,now);history.push({...h,phase:b.phase,periodEnd:new Date(hb.end).toISOString(),reviewed:h.payrollApproved});}
  const analysis=evaluate(current,history,cfg);const personalSignals=signals.filter(x=>x.person===person.id).map(x=>({code:x.code,message:x.message,sessionId:x.sessionId||null}));const inputFingerprint=fingerprint({version:VERSION,revision:s.overtimeWatch.revision,week,current,history,personalSignals});const review=s.overtimeWatch.reviews.findLast(r=>r.employee===person.id&&r.week===week&&r.fingerprint===inputFingerprint);
  if(personalSignals.length)analysis.warnings.push('Separate Personal clock evidence requires attention. It is not added to approved overtime.');
  rows.push({employee:person.id,name:person.name,site:person.site,job:person.job,...analysis,source:current.source,sourceStatus:current.payrollApproved?'payroll-reviewed':'recorded / unreviewed',signals:personalSignals,review:review?{status:review.status,reason:review.reason,by:review.by,at:review.at}:null,fingerprint:inputFingerprint,...(a.costs?{grossPence:current.grossPence??null,expectedGrossPence:current.expectedGrossPence??null}:{})});
 }
 return {page:{offset,limit,total:allPeople.length,hasMore:offset+people.length<allPeople.length},week,through:new Date(b.through).toISOString(),version:s.version,configurationRevision:s.overtimeWatch.revision,settings:cfg,rows,generatedAt:new Date(now).toISOString(),warning:'Decision support only. No payroll, disciplinary or scheduling decision is automated. Incomplete data stays unverified.'};
}
function configure(s,a,x){assert((a.permissions||[]).includes('company.configure'),'Company configuration permission required.',403);decorate(s);assert(x.revision===s.overtimeWatch.revision,'Overtime settings changed; refresh first.',409);assert(typeof x.reason==='string'&&x.reason.trim().length>=8&&x.reason.length<=400,'A reason is required.');assert(Object.keys(x.settings||{}).every(k=>k in DEFAULT),'Unknown overtime setting.');s.overtimeWatch.settings=settings(x.settings);s.overtimeWatch.revision++;return {id:'overtime-settings',revision:s.overtimeWatch.revision};}
function review(s,a,x,now=Date.now(),signals=[]){authorised(s,a,x.employee);assert(['needs_information','explained','correction_requested'].includes(x.status),'Choose a review outcome.');assert(typeof x.reason==='string'&&x.reason.trim().length>=8&&x.reason.length<=400,'A factual review reason is required.');const row=report(s,a,x.week,now,signals,{employee:x.employee}).rows.find(r=>r.employee===x.employee);assert(row.fingerprint===x.fingerprint,'Attendance, policy or history changed. Refresh the evidence before reviewing.',409);assert(x.employee!==a.personId,'You cannot review your own overtime.',403);assert(s.overtimeWatch.reviews.length<20000,'Review archive limit reached; retain records and plan archival.',409);s.overtimeWatch.reviews.push({employee:x.employee,week:x.week,fingerprint:x.fingerprint,status:x.status,reason:x.reason.trim(),by:a.personId,at:new Date(now).toISOString()});return {id:x.employee+':'+x.week,status:x.status};}
const api={VERSION,DEFAULT,settings,median,evaluate,decorate,regime,bounds,evidence,report,configure,review};if(typeof module!=='undefined'&&module.exports)module.exports=api;root.WFMOvertimeWatch=api;
})(typeof window!=='undefined'?window:globalThis);
