/* Personal self-service rules. Shared by the application and the synthetic time runner.
   This module never authorises a user: authenticated subject/tenant are resolved by the server. */
(function(root){'use strict';
const MIN=60000,MAX_SPAN=26*60*MIN;
function check(ok,message,status=400){if(!ok){const e=Error(message);e.status=status;throw e;}}
const FIELDS=['preferredName','phone','personalEmail','address','emergencyName','emergencyPhone','locale'];
const SECTIONS=['hours','holidays','shifts','profile'];
const ROLES=['employee','manager','supervisor','director','payroll_admin','admin'];
function defaults(){return {revision:0,sections:SECTIONS.slice(),editableFields:FIELDS.slice(),clockEnabled:false,clockRoles:ROLES.slice(),breakPaid:false,breakAfterMinutes:360,breakAllowanceMinutes:20,minContinuousMinutes:20};}
function policy(value){const p={...defaults(),...value};check(Array.isArray(p.sections)&&p.sections.every(x=>SECTIONS.includes(x))&&new Set(p.sections).size===p.sections.length,'Invalid Personal sections.');check(Array.isArray(p.editableFields)&&p.editableFields.every(x=>FIELDS.includes(x))&&new Set(p.editableFields).size===p.editableFields.length,'Protected employee fields cannot be made self-editable.');check(Array.isArray(p.clockRoles)&&p.clockRoles.every(x=>ROLES.includes(x)),'Invalid clocking roles.');check(typeof p.clockEnabled==='boolean'&&typeof p.breakPaid==='boolean','Clock and paid-break options must be true or false.');for(const k of ['breakAfterMinutes','breakAllowanceMinutes','minContinuousMinutes'])check(Number.isSafeInteger(p[k])&&p[k]>=0&&p[k]<=780,'Invalid break minutes.');check(p.minContinuousMinutes<=p.breakAllowanceMinutes,'Uninterrupted minimum cannot exceed total break allowance.');return p;}
function validateProfile(fields,p){check(fields&&typeof fields==='object'&&!Array.isArray(fields),'Profile fields are required.');const out={};for(const [k,v]of Object.entries(fields)){check(FIELDS.includes(k)&&p.editableFields.includes(k),'This personal field is not editable: '+k,403);check(typeof v==='string','Profile values must be text.');const val=v.trim();check(val.length<=(k==='address'?300:120)&&!/[\x00-\x08\x0B\x0C\x0E-\x1F]/.test(val),'Invalid personal field value.');if(k==='personalEmail'&&val)check(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val),'Enter a valid contact email. This does not change your sign-in.');if(k==='locale')check(['en-GB','fr-FR','de-DE','pl-PL','ro-RO'].includes(val),'Unsupported display locale.');out[k]=val;}return out;}
function emptyClock(){return {revision:0,status:'out',active:null,lastAt:null};}
function clockStep(state,type,at,p,role='employee'){
 check(Number.isSafeInteger(at)&&at>=0,'Invalid server time.');check(['in','out','break_start','break_end','break_end_out'].includes(type),'Unknown clock event.');
 check(state.lastAt==null||at>=state.lastAt,'Clock sequence moved backwards. A reviewed correction is required.',409);
 const q={...state,revision:state.revision+1,lastAt:at};let completed=null;
 if(type==='in'){
  check(p.clockEnabled&&p.clockRoles.includes(role),'Personal clock-in is disabled by your company.',403);check(state.status==='out','You are already clocked in.',409);
  q.status='in';q.active={start:at,breakStart:null,breaks:[],policy:{revision:p.revision,breakPaid:p.breakPaid,breakAfterMinutes:p.breakAfterMinutes,breakAllowanceMinutes:p.breakAllowanceMinutes,minContinuousMinutes:p.minContinuousMinutes,applicableBreakRules:p.applicableBreakRules||[]}};
 }else{
  check(state.active&&state.status!=='out','Clock in before recording this event.',409);
  // Capture an explicit late departure, but quarantine its duration for review. Never strand the worker.
  const overlong=at-state.active.start>MAX_SPAN;
  check(!overlong||type==='out'||type==='break_end'||type==='break_end_out','This old session needs closing and manager review before another break can start.',409);
  q.active={...state.active,breaks:state.active.breaks.slice()};
  if(type==='break_start'){check(state.status==='in','A break is already open.',409);check(q.active.breaks.length<20,'Too many break intervals; manager review required.',409);q.active.breakStart=at;q.status='break';}
  if(type==='break_end'||type==='break_end_out'){check(state.status==='break','There is no open break.',409);check(at>q.active.breakStart,'Break end must be after its start.',409);q.active.breaks.push({start:q.active.breakStart,end:at,paid:q.active.policy.breakPaid});q.active.breakStart=null;q.status='in';}
  if(type==='out'||type==='break_end_out'){
   check(state.status==='in'||type==='break_end_out','End your break before clocking out.',409);check(at>q.active.start,'Clock-out must follow clock-in.',409);
   const bs=q.active.breaks;const breakMs=bs.reduce((n,b)=>n+b.end-b.start,0),unpaidMs=bs.filter(b=>!b.paid).reduce((n,b)=>n+b.end-b.start,0),elapsedMs=at-q.active.start,workedMs=elapsedMs-breakMs;
   const rules=q.active.policy,triggered=(rules.applicableBreakRules||[]).filter(r=>workedMs>r.afterMinutes*MIN),required=Math.max(workedMs>rules.breakAfterMinutes*MIN?rules.breakAllowanceMinutes:0,workedMs>360*MIN?20:0,...triggered.map(r=>r.allowanceMinutes));
   const longest=bs.reduce((n,b)=>Math.max(n,b.end-b.start),0);completed={start:q.active.start,end:at,breaks:bs,elapsedMs,workedMs,payableMs:elapsedMs-unpaidMs,paidBreakMs:breakMs-unpaidMs,unpaidBreakMs:unpaidMs,requiredBreakMinutes:required,breakReview:breakMs<required*MIN||(required>0&&longest<Math.max(rules.minContinuousMinutes,workedMs>360*MIN?20:0,...triggered.map(r=>r.minContinuousMinutes||0))*MIN),paidBreakReview:breakMs-unpaidMs<Math.max(0,...triggered.map(r=>r.paidAllowanceMinutes||0))*MIN,appliedBreakRuleIds:triggered.map(r=>r.id),durationReview:overlong,reviewReason:overlong?'LONG_SESSION_RECORDED_REQUIRES_REVIEW':null,explicitBreakEnd:type==='break_end_out',policyRevision:rules.revision,source:'authenticated-personal-web',payrollApproved:false};q.active=null;q.status='out';
  }
 }
 return {state:q,completed};
}
function sliceSession(s,lo,hi){const start=Math.max(s.start,lo),end=Math.min(s.end,hi);if(end<=start)return {elapsedMs:0,workedMs:0,payableMs:0};let all=0,unpaid=0;for(const b of s.breaks){const d=Math.max(0,Math.min(end,b.end)-Math.max(start,b.start));all+=d;if(!b.paid)unpaid+=d;}return {elapsedMs:end-start,workedMs:end-start-all,payableMs:end-start-unpaid};}
const api={FIELDS,SECTIONS,ROLES,MIN,defaults,policy,validateProfile,emptyClock,clockStep,sliceSession,check};if(typeof module!=='undefined')module.exports=api;root.WFMPersonal=api;
})(typeof window!=='undefined'?window:globalThis);
